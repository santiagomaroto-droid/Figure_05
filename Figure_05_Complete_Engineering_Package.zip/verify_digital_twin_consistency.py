"""
Figure 05 - Cross-Artifact Digital Twin Consistency & CAD/Physics Auditor
=========================================================================
Authors: Santiago Maroto (Lead Researcher) & Project Figure 05 Engineering Group
Target: Kyle Edelberg & Brett Adcock, Figure AI

Programmatically cross-verifies coherence across EVERY engineering artifact in
the repository to eliminate silent spec drift or unbacked claims:
1. MuJoCo 3.6 XML (`figure05_mujoco.xml`) total body mass == URDF
   (`figure05_kinematics.urdf`) total mass == 54.50 kg (<= 0.01 kg drift),
   and Class Gamma peak torque caps match hardware ratings (510.0 Nm).
2. Binary STL CAD meshes (Sun Gear, Planet Carrier Assembly, Ring Housing,
   Structural Pelvis Monocoque) are non-empty, valid binary STL format with
   exact triangle byte length and zero NaN/Inf coordinates.
3. All generated telemetry JSON reports satisfy safety/physical invariants
   (0.0 N skyhook across stance/walk/deadlift, AGMA SF >= 1.5, Bearing L10h
   > 100,000 h, Sim2Real >= 75% over 96 worlds, 0 RTOS deadline misses across
   10,000 ticks, causal oracle-free tactile reflex, residual err <= 0.05 mm).
4. Bill of Materials CSV sums strictly to <= $18,450 USD target at 50k scale.
5. GitHub CI workflow, requirements.txt, and interactive index.html exist cleanly.
"""

from collections import Counter
import json
import os
import struct
import xml.etree.ElementTree as ET
import mujoco
import numpy as np
import pandas as pd


def verify_binary_stl(path: str):
    """Validate binary STL structure, closed manifold edge pairing, positive signed volume, and finite vertices."""
    assert os.path.isfile(path), f"Missing CAD STL file: {path}"
    with open(path, "rb") as f:
        header = f.read(80)
        assert len(header) == 80, f"Truncated STL header: {path}"
        n_tris = struct.unpack("<I", f.read(4))[0]
        assert n_tris >= 100, f"Degenerate triangle count ({n_tris}) in {path}"
        data = f.read()
    expected_bytes = n_tris * 50
    assert len(data) == expected_bytes, (
        f"Binary STL byte mismatch in {path}: got {len(data)}, expected {expected_bytes}"
    )
    arr = np.frombuffer(data, dtype=np.uint8).reshape(n_tris, 50)
    floats = arr[:, :48].view("<f4")
    assert np.all(np.isfinite(floats)), f"NaN/Inf coordinates detected in {path}"

    verts = np.round(floats.reshape(n_tris, 4, 3)[:, 1:4, :], 6)
    edges = Counter()
    vol = 0.0
    for tri in verts:
        a, b, c = tuple(tri[0]), tuple(tri[1]), tuple(tri[2])
        vol += float(np.dot(tri[0], np.cross(tri[1], tri[2]))) / 6.0
        for u, v in ((a, b), (b, c), (c, a)):
            e = (u, v) if u < v else (v, u)
            edges[e] += 1
    open_edges = sum(1 for count in edges.values() if count % 2 != 0)
    assert open_edges == 0, f"Non-watertight CAD mesh {path}: {open_edges} open boundary edges"
    assert vol > 0.0, f"Inverted outward surface normals (negative volume {vol:.3e}) in {path}"
    return int(n_tris), round(vol * 1e6, 2)


def run_cross_artifact_audit():
    print("=================================================================")
    print("FIGURE 05: CROSS-ARTIFACT DIGITAL TWIN CONSISTENCY AUDITOR")
    print("=================================================================")

    base_dir = os.path.dirname(os.path.abspath(__file__))

    # 1. Cross-check MuJoCo XML vs URDF Mass & Actuator Limits
    mj_model = mujoco.MjModel.from_xml_path(os.path.join(base_dir, "figure05_mujoco.xml"))
    mujoco_mass = float(np.sum(mj_model.body_mass))

    urdf_root = ET.parse(os.path.join(base_dir, "figure05_kinematics.urdf")).getroot()
    urdf_masses = []
    for link in urdf_root.findall("./link"):
        inert = link.find("inertial")
        m_elem = inert.find("mass")
        ii = inert.find("inertia")
        urdf_masses.append(float(m_elem.attrib["value"]))
        ixx, iyy, izz = float(ii.attrib["ixx"]), float(ii.attrib["iyy"]), float(ii.attrib["izz"])
        assert ixx > 0 and iyy > 0 and izz > 0, f"Non-positive inertia on link {link.attrib['name']}"
        assert (ixx + iyy + 1e-9 >= izz) and (ixx + izz + 1e-9 >= iyy) and (iyy + izz + 1e-9 >= ixx), (
            f"Physical inertia triangle inequality violated on link {link.attrib['name']}: {(ixx, iyy, izz)}"
        )
    urdf_mass = float(sum(urdf_masses))
    mass_diff = abs(mujoco_mass - urdf_mass)

    print(
        f"[*] Mass & Inertia Verified -> MuJoCo: {mujoco_mass:.2f} kg | URDF ({len(urdf_masses)} links): {urdf_mass:.2f} kg (Delta: {mass_diff:.4f} kg)"
    )
    assert abs(mujoco_mass - 54.50) < 0.01, f"MuJoCo mass drifted: {mujoco_mass}"
    assert mass_diff < 0.01, f"MuJoCo vs URDF mass mismatch: {mass_diff}"

    for knee_name in ("act_left_knee", "act_right_knee", "act_left_hip_pitch", "act_right_hip_pitch"):
        aid = mj_model.actuator(knee_name).id
        rng = mj_model.actuator_ctrlrange[aid]
        assert np.allclose(rng, [-510.0, 510.0]), f"Class Gamma limit mismatch on {knee_name}: {rng}"

    # 2. Validate 4 Watertight Manifold Binary CAD STLs
    stl_files = [
        "class_gamma_sun_gear.stl",
        "class_gamma_planetary_assembly.stl",
        "class_gamma_housing.stl",
        "figure05_monocoque_pelvis.stl",
    ]
    total_tris = 0
    for fn in stl_files:
        tris, vol_cm3 = verify_binary_stl(os.path.join(base_dir, fn))
        total_tris += tris
        print(f"    [STL WATERTIGHT] {fn}: {tris:,} tris | {vol_cm3:.2f} cm3 (0 open edges)")
    assert total_tris > 20000

    # 3. Validate All Telemetry JSON Reports & Safety Invariants
    def load_json(name):
        with open(os.path.join(base_dir, name), "r", encoding="utf-8") as f:
            return json.load(f)

    stress = load_json("class_gamma_stress_report.json")
    assert stress["bending_safety_factor_peak"] >= 1.5
    assert stress["contact_safety_factor_peak"] >= 1.5
    assert stress["planet_bearing_l10h_heavy_rms_hours"] > 100000.0
    assert stress["total_reduction_ratio"] == 18.0

    wbc = load_json("figure05_mujoco_telemetry.json")
    assert wbc["skyhook_forces_used"] is False and wbc["peak_roll_deviation_deg"] < 15.0
    assert wbc["steady_state_total_grf_n"] > 500.0

    walk = load_json("figure05_walking_telemetry.json")
    assert walk["skyhook_force_n"] == 0.0 and walk["completed_without_fall"] is True
    assert walk["distance_walked_m"] >= 2.0 and walk["mid_stride_push_n"] >= 50.0

    ramp = load_json("figure05_ramp_telemetry.json")
    assert ramp["skyhook_force_n"] == 0.0 and ramp["completed_without_fall"] is True
    assert ramp["ramp_angle_deg"] == 10.0 and ramp["elevation_gain_m"] >= 0.25

    stepup = load_json("figure05_stepup_telemetry.json")
    assert stepup["skyhook_force_n"] == 0.0 and stepup["completed_without_fall"] is True
    assert stepup["step_height_mm"] == 75.0 and stepup["both_feet_mounted_upper_deck"] is True
    assert os.path.isfile(os.path.join(base_dir, "tests", "test_figure05_fast.py")), "Missing fast unittest suite"

    stepdown = load_json("figure05_stepdown_telemetry.json")
    assert stepdown["skyhook_force_n"] == 0.0 and stepdown["completed_without_fall"] is True
    assert stepdown["drop_height_mm"] == 75.0 and stepdown["both_feet_descended_to_floor"] is True

    stairs = load_json("figure05_stairs_telemetry.json")
    assert stairs["skyhook_force_n"] == 0.0 and stairs["completed_without_fall"] is True
    assert stairs["num_risers"] == 2 and stairs["total_stair_elevation_mm"] == 140.0
    assert stairs["both_feet_mounted_top_step"] is True and stairs["peak_knee_torque_nm"] < 220.0

    stair_down = load_json("figure05_stair_descent_telemetry.json")
    assert stair_down["skyhook_force_n"] == 0.0 and stair_down["completed_without_fall"] is True
    assert stair_down["both_feet_descended_stairs"] is True and stair_down["total_stair_descent_mm"] == 140.0
    assert stair_down["net_dc_bus_regen_energy_j"] > 50.0 and stair_down["peak_knee_torque_nm"] < 220.0

    slippery = load_json("figure05_slippery_walk_telemetry.json")
    assert slippery["skyhook_force_n"] == 0.0 and slippery["zero_oracle_controller"] is True
    assert slippery["ab_baseline_unmitigated"]["survived"] is False
    ad_slip = slippery["adaptive_blind_friction_cone"]
    assert ad_slip["survived"] is True and ad_slip["cleared_oil_patch"] is True
    assert ad_slip["min_mu_hat_detected"] <= 0.25 and ad_slip["final_mu_hat"] > ad_slip["min_mu_hat_detected"] + 0.10

    trip = load_json("figure05_trip_recovery_telemetry.json")
    assert trip["skyhook_force_n"] == 0.0 and trip["zero_oracle_controller"] is True
    assert trip["ab_baseline_tripped"]["survived"] is False
    ad_trip = trip["adaptive_elevating_reflex"]
    assert ad_trip["survived"] is True and ad_trip["cleared_obstacle_cleat"] is True
    assert ad_trip["reflex_triggers"] >= 1 and ad_trip["peak_vault_clearance_mm"] > trip["cleat_height_mm"] + 10.0

    loaded = load_json("figure05_loaded_walk_telemetry.json")
    assert loaded["skyhook_force_n"] == 0.0 and loaded["completed_without_fall"] is True
    assert loaded["tote_carried_without_drop"] is True and loaded["combined_mass_kg"] == 69.5
    assert abs(loaded["steady_mean_total_grf_n"] - loaded["theoretical_weight_n"]) < 10.0

    loco = load_json("figure05_locomanip_telemetry.json")
    assert loco["skyhook_force_n"] == 0.0 and loco["completed_without_fall"] is True
    assert loco["tote_placed_and_released"] is True and loco["tote_transport_m"] >= 1.10
    assert loco["grasp_engaged_time_s"] < loco["grasp_released_time_s"]
    assert loco["peak_knee_torque_nm"] < 220.0

    cart_push = load_json("figure05_cart_push_telemetry.json")
    assert cart_push["skyhook_force_n"] == 0.0 and cart_push["unlatched_pure_contact"] is True
    assert cart_push["completed_without_fall"] is True and cart_push["cart_mass_kg"] == 65.0
    assert cart_push["cart_pushed_distance_m"] >= 1.15 and cart_push["post_release_push_force_n"] <= 1.0

    turn = load_json("figure05_turning_telemetry.json")
    assert turn["skyhook_force_n"] == 0.0 and turn["completed_without_fall"] is True
    assert turn["achieved_90deg_turn"] is True and turn["final_yaw_deg"] >= 90.0
    assert turn["yaw_tracking_rms_deg"] <= 5.0 and turn["path_length_m"] >= 1.8

    sidestep = load_json("figure05_sidestep_telemetry.json")
    assert sidestep["skyhook_force_n"] == 0.0 and sidestep["completed_without_fall"] is True
    assert sidestep["total_lateral_path_m"] >= 1.25 and sidestep["min_inter_foot_y_clearance_m"] >= 0.120
    assert sidestep["yaw_rms_deg"] < 6.0 and sidestep["sagittal_shove_rejected_n"] == 65.0

    push_rec = load_json("figure05_push_recovery_telemetry.json")
    assert push_rec["skyhook_force_n"] == 0.0 and push_rec["zero_oracle_controller"] is True
    assert push_rec["baseline_directions_survived"] == 0 and push_rec["reactive_directions_survived"] == 4
    assert push_rec["false_triggers_before_push"] == 0 and push_rec["min_inter_foot_y_clearance_m"] >= 0.120
    assert push_rec["peak_knee_torque_nm"] < 260.0 and push_rec["mean_detection_latency_ms"] <= 100.0

    door = load_json("figure05_door_traversal_telemetry.json")
    assert door["skyhook_force_n"] == 0.0 and door["zero_oracle_controller"] is True
    assert door["baseline_naive_walk"]["traversed_doorway"] is False
    door_ok = door["causal_locomanip_traversal"]
    assert door_ok["survived"] is True and door_ok["traversed_doorway"] is True
    assert door_ok["peak_door_angle_deg"] >= 75.0 and door_ok["final_door_angle_deg"] < 15.0
    assert door_ok["post_release_palm_force_n"] <= 0.5 and door_ok["peak_knee_torque_nm"] < 220.0

    uneven = load_json("figure05_uneven_terrain_telemetry.json")
    assert uneven["skyhook_force_n"] == 0.0 and uneven["zero_oracle_controller"] is True
    assert uneven["canted_plate_count"] == 12
    assert uneven["baseline_flat_nominal"]["survived"] is False
    uneven_ok = uneven["causal_proprioceptive_adaptive"]
    assert uneven_ok["survived"] is True and uneven_ok["traversed_field"] is True
    assert uneven_ok["max_detected_terrain_z_mm"] >= 45.0
    assert uneven_ok["max_adapted_sole_tilt_deg"] >= 5.0 and uneven_ok["peak_knee_torque_nm"] < 200.0

    gantry = load_json("figure05_gantry_duck_telemetry.json")
    assert gantry["skyhook_force_n"] == 0.0 and gantry["zero_oracle_controller"] is True
    assert gantry["baseline_upright_walk"]["traversed_gantry"] is False
    assert gantry["baseline_upright_walk"]["peak_gantry_impact_force_n"] >= 150.0
    gantry_ok = gantry["whole_body_crouch_walk"]
    assert gantry_ok["survived"] is True and gantry_ok["traversed_gantry"] is True
    assert gantry_ok["peak_gantry_impact_force_n"] == 0.0
    assert gantry_ok["min_head_clearance_mm"] >= 20.0
    assert gantry_ok["post_gantry_recovered_com_z_m"] >= 0.83 and gantry_ok["peak_knee_torque_nm"] < 220.0

    gait = load_json("figure05_gait_summary.json")
    assert gait["sustained_velocity_m_s"] >= 0.80 and gait["min_zmp_stability_margin_mm"] >= 35.0

    deadlift = load_json("figure05_deadlift_telemetry.json")
    assert deadlift["skyhook_force_n"] == 0.0 and deadlift["within_all_actuator_limits"] is True
    assert deadlift["steel_crate_mass_kg"] == 45.0 and deadlift["min_sole_stability_margin_mm"] > 30.0

    sim2real = load_json("figure05_sim2real_metrics.json")
    assert sim2real["randomized_environments_count"] == 96
    assert sim2real["causal_blind_nominal_wbc"] is True
    assert sim2real["zero_shot_sim2real_transfer_rate_pct"] >= 90.0

    neural = load_json("figure05_neural_metrics.json")
    assert neural["wbc_deadline_misses"] == 0 and neural["wbc_monte_carlo_ticks"] == 10000

    tactile = load_json("figure05_tactile_metrics.json")
    assert tactile["causal_controller_oracle_free"] is True and tactile["gelskin_reflex_slip_mm"] < 1.5

    cycle = load_json("figure05_cycle_benchmark.json")
    assert cycle["insertion_residual_error_mm"] <= 0.05 and cycle["fleet_oee_percent"] >= 90.0

    dyn = load_json("figure05_simulation_metrics.json")
    assert dyn["steady_state_housing_temp_c"] < dyn["steady_state_stator_temp_c"] < dyn["steady_state_winding_temp_c"] < 115.0
    assert dyn["soc_remaining_percent"] >= 20.0

    safety_bus = load_json("figure05_safety_bus_metrics.json")
    assert safety_bus["figure05_peak_contact_force_n"] < 140.0
    assert safety_bus["figure05_impact_energy_j"] < 0.49
    assert safety_bus["max_gptp_jitter_ns"] < 35.0
    assert safety_bus["dropped_10khz_frames_during_cut"] == 0

    # 4. Validate BOM CSV integrity
    bom_df = pd.read_csv(os.path.join(base_dir, "figure05_detailed_bom.csv"))
    bom_50k = float(bom_df["Total_50k"].sum())
    assert abs(bom_50k - 17878.0) < 1.0, f"Unexpected 50k BOM sum: {bom_50k}"
    print(f"[*] BOM CSV Verified: ${bom_50k:,.2f} USD @ 50k/yr (<= $18,450 ceiling)")

    # 5. Essential CI/CD & WebGL files present + Version & Dependency Audit
    for req in ("VERSION", "CHANGELOG.md", "requirements.txt", "LICENSE", "index.html", ".github/workflows/ci_validation.yml"):
        assert os.path.isfile(os.path.join(base_dir, req)), f"Missing required repo artifact: {req}"

    with open(os.path.join(base_dir, "VERSION"), "r", encoding="utf-8") as vf:
        release_ver = vf.read().strip()
    assert release_ver.count(".") == 2, f"Non-semver VERSION string: {release_ver}"

    versioned_docs = [
        "CHANGELOG.md",
        "README.md",
        "FIGURE_05_OFFICIAL_DATASHEET.md",
        "FIGURE_05_MASTER_BLUEPRINT.md",
        "FIGURE_05_EXECUTIVE_PITCH_DECK.md",
        "NEURAL_ARCHITECTURE.md",
        "SAFETY_AND_COMPLIANCE_SPEC.md",
        "COMMUNICATION_BUS_SPEC.md",
        "index.html",
    ]
    for doc_name in versioned_docs:
        with open(os.path.join(base_dir, doc_name), "r", encoding="utf-8") as df:
            txt = df.read()
        assert release_ver in txt, f"Version drift: {doc_name} does not reference v{release_ver}"

    with open(os.path.join(base_dir, "index.html"), "r", encoding="utf-8") as hf:
        html_txt = hf.read()
    assert "three@0.128.0/build/three.min.js" in html_txt and "three@0.128.0/examples/js/controls/OrbitControls.js" in html_txt, (
        "WebGL Three.js CDN versions drifted or split across CDNs in index.html"
    )

    mj_ver_tuple = tuple(int(x) for x in mujoco.__version__.split(".")[:2])
    assert mj_ver_tuple >= (3, 6), f"Unsupported MuJoCo version: {mujoco.__version__}"
    print(f"[*] Version Audit Verified: Release v{release_ver} synced across {len(versioned_docs)} files | MuJoCo {mujoco.__version__}")

    audit_summary = {
        "audit_status": "ALL_DIGITAL_TWIN_ARTIFACTS_COHERENT",
        "release_version": release_ver,
        "mujoco_runtime_version": mujoco.__version__,
        "checked_versioned_files": len(versioned_docs) + 1,
        "mujoco_mass_kg": round(mujoco_mass, 4),
        "urdf_mass_kg": round(urdf_mass, 4),
        "mass_discrepancy_kg": round(mass_diff, 6),
        "stl_total_triangles": total_tris,
        "skyhook_verified_zero_across_all_mujoco_runs": True,
        "verified_bom_50k_usd": bom_50k,
        "verified_json_reports": 27,
    }
    with open(os.path.join(base_dir, "figure05_digital_twin_audit.json"), "w", encoding="utf-8") as f:
        json.dump(audit_summary, f, indent=4)

    print("[+] CROSS-ARTIFACT AUDIT PASSED: ZERO DRIFT ACROSS CAD, URDF, MUJOCO, BOM & TELEMETRY")


if __name__ == "__main__":
    run_cross_artifact_audit()
