"""
Figure 05 - Skyhook-Free MuJoCo 3.6 Curved >= 90-Deg Aisle Turning Locomotion
=============================================================================
Authors: Santiago Maroto (Lead Researcher) & Project Figure 05 Engineering Group
Target: Kyle Edelberg & Brett Adcock, Figure AI

Architecture (100% Pure Rigid-Body Physics, Zero Skyhook Forces):
1. Strict skyhook prohibition: `data.qfrc_applied[:] = 0.0` at every 500 Hz step.
2. Smooth C1 yaw steering profile (`0 deg -> +100 deg` Left factory aisle corner turn)
   transforming DCM Capture Point footholds into the moving SE(2) body heading frame
   with strict lateral foot-separation bounds so feet never cross at any yaw angle.
3. Exact stance-sole-local ZMP COP wrench projection (`r_cur^T * (zmp - p_cur)` rotated
   back via `r_cur * m_cop_local`) ensuring full 360-degree yaw invariance across the
   26 cm x 13.6 cm sole polygon.
4. Coordinated swing-foot yaw steering (`R_z(psi_tgt)`) via hip-yaw actuation while
   holding the planted stance sole yaw steady (`no floor scuffing`).
"""

import json
import os

import matplotlib.pyplot as plt
import mujoco
import numpy as np

from figure05_mujoco_common import (
    build_actuator_mappings,
    mat_to_rotvec_err,
    quat_to_roll_pitch_yaw,
    rot_z,
    setup_crouched_biped,
    sum_support_grfs,
    wrap_angle_diff,
)


def yaw_schedule(t: float, t_start: float = 0.8, t_end: float = 7.6, target_deg: float = 100.0) -> tuple[float, float]:
    """Return `(yaw_rad, omega_yaw_rad_s)` along a C1 cosine-blended turn profile."""
    yaw_total = float(np.deg2rad(target_deg))
    if t <= t_start:
        return 0.0, 0.0
    if t >= t_end:
        return yaw_total, 0.0
    u = (t - t_start) / (t_end - t_start)
    yaw = yaw_total * (0.5 - 0.5 * np.cos(np.pi * u))
    omega_yaw = yaw_total * (0.5 * np.pi / (t_end - t_start)) * np.sin(np.pi * u)
    return float(yaw), float(omega_yaw)


def run_turning_walk_simulation(verbose: bool = False) -> None:
    print("=================================================================")
    print("FIGURE 05: SKYHOOK-FREE MUJOCO 3.6 CURVED 100-DEG AISLE TURN WALK")
    print("=================================================================")

    base_dir = os.path.dirname(os.path.abspath(__file__))
    xml_path = os.path.join(base_dir, "figure05_mujoco.xml")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)

    dt = model.opt.timestep
    g = 9.80665
    total_mass = float(np.sum(model.body_mass))

    setup_crouched_biped(model, data)

    maps = build_actuator_mappings(model)
    act_qidx = maps["act_qidx"]
    act_vidx = maps["act_vidx"]
    idx_map = maps["idx_map"]
    l_leg_v = maps["l_leg_v"]
    r_leg_v = maps["r_leg_v"]
    l_leg_act = maps["l_leg_act"]
    r_leg_act = maps["r_leg_act"]
    upper_act = maps["upper_act"]
    q_init = np.array([data.qpos[idx] for idx in act_qidx])

    l_site = model.site("left_foot_contact").id
    r_site = model.site("right_foot_contact").id
    l_body = model.body("left_ankle").id
    r_body = model.body("right_ankle").id
    floor_geom = model.geom("floor").id
    pelvis_id = model.body("pelvis").id

    jac_com = np.zeros((3, model.nv))
    jac_p_l = np.zeros((3, model.nv))
    jac_r_l = np.zeros((3, model.nv))
    jac_p_r = np.zeros((3, model.nv))
    jac_r_r = np.zeros((3, model.nv))

    # Gait & DCM parameters
    step_T = 0.42
    ds_frac = 0.16
    half_y = 0.105
    swing_clear = 0.072
    z_nom = 0.870
    omega = np.sqrt(g / z_nom)
    b_val = np.exp(omega * step_T)
    y_off_nom = (2.0 * half_y) / (b_val + 1.0)
    k_dcm = 1.45

    duration_s = 8.0
    n_steps = int(duration_s / dt)
    settle_steps = 140

    swing_side = "left"
    sw_start_pos = data.site_xpos[l_site].copy()
    sw_start_yaw = 0.0
    sw_tgt_yaw = 0.0
    st_hold_yaw_l = 0.0
    st_hold_yaw_r = 0.0

    v_fwd_target = 0.32
    sw_tgt_xy = sw_start_pos[:2] + np.array([0.5 * v_fwd_target * step_T, 0.0])

    l_knee_id = idx_map["act_left_knee"]
    r_knee_id = idx_map["act_right_knee"]

    t_hist, x_hist, y_hist, yaw_hist, yaw_ref_hist = [], [], [], [], []
    roll_hist, pitch_hist = [], []
    lf_xy_hist, rf_xy_hist = [], []
    l_grf_hist, r_grf_hist = [], []
    knee_trq_hist = []
    fallen = False

    r_pitch_lean = np.array([
        [np.cos(0.035), 0.0, np.sin(0.035)],
        [0.0, 1.0, 0.0],
        [-np.sin(0.035), 0.0, np.cos(0.035)],
    ])

    for step in range(n_steps):
        t = step * dt
        mujoco.mj_forward(model, data)

        # CRITICAL: ZERO SKYHOOK FORCES
        data.qfrc_applied[:] = 0.0

        p_l = data.site_xpos[l_site].copy()
        p_r = data.site_xpos[r_site].copy()
        r_l = data.site_xmat[l_site].reshape(3, 3)
        r_r = data.site_xmat[r_site].reshape(3, 3)

        mujoco.mj_jacSubtreeCom(model, data, jac_com, pelvis_id)
        p_com = data.subtree_com[pelvis_id].copy()
        v_com = jac_com @ data.qvel

        mujoco.mj_jacSite(model, data, jac_p_l, jac_r_l, l_site)
        mujoco.mj_jacSite(model, data, jac_p_r, jac_r_r, r_site)
        v_l = jac_p_l @ data.qvel
        w_l = jac_r_l @ data.qvel
        v_r = jac_p_r @ data.qvel
        w_r = jac_r_r @ data.qvel

        pelv_mat = data.body("pelvis").xmat.reshape(3, 3)
        pelv_w = data.qvel[3:6].copy()
        _, _, yaw_pelv = quat_to_roll_pitch_yaw(data.qpos[3:7])
        r_body_upright = rot_z(yaw_pelv).T @ pelv_mat
        roll_pelv = float(np.arctan2(r_body_upright[2, 1], r_body_upright[2, 2]))
        pitch_pelv = float(-np.arcsin(np.clip(r_body_upright[2, 0], -1.0, 1.0)))

        l_grf, r_grf = sum_support_grfs(model, data, (floor_geom,), l_body, r_body)

        psi_cmd, omega_yaw = yaw_schedule(t)
        u_fwd = np.array([np.cos(psi_cmd), np.sin(psi_cmd)])
        u_lat = np.array([-np.sin(psi_cmd), np.cos(psi_cmd)])

        t_hist.append(t)
        x_hist.append(float(data.qpos[0]))
        y_hist.append(float(data.qpos[1]))
        yaw_hist.append(float(np.rad2deg(yaw_pelv)))
        yaw_ref_hist.append(float(np.rad2deg(psi_cmd)))
        roll_hist.append(float(np.rad2deg(roll_pelv)))
        pitch_hist.append(float(np.rad2deg(pitch_pelv)))
        lf_xy_hist.append([float(p_l[0]), float(p_l[1])])
        rf_xy_hist.append([float(p_r[0]), float(p_r[1])])
        l_grf_hist.append(l_grf)
        r_grf_hist.append(r_grf)

        if data.qpos[2] < 0.45:
            fallen = True
            print(f"[ABORT] Fall detected at t={t:.2f}s Z_pel={data.qpos[2]:.3f}m")
            break

        tau_step = 0.0
        step_num = 0
        if step < settle_steps:
            in_ds = True
            phase_sw = 0.0
            s_sign = 1.0
            if step == settle_steps - 1:
                sw_start_pos = p_l.copy()
                sw_start_yaw = float(np.arctan2(r_l[1, 0], r_l[0, 0]))
                sw_tgt_yaw = psi_cmd
                st_hold_yaw_r = float(np.arctan2(r_r[1, 0], r_r[0, 0]))
                sw_tgt_xy = p_r[:2] + 0.14 * u_fwd + (2.0 * half_y) * u_lat
        else:
            step_idx = step - settle_steps
            ticks_per_step = int(step_T / dt)
            step_num = step_idx // ticks_per_step
            tau_step = (step_idx % ticks_per_step) * dt
            if step_idx % ticks_per_step == 0 and step_idx > 0:
                swing_side = "right" if swing_side == "left" else "left"
                if swing_side == "left":
                    sw_start_pos = p_l.copy()
                    sw_start_yaw = float(np.arctan2(r_l[1, 0], r_l[0, 0]))
                    st_hold_yaw_r = float(np.arctan2(r_r[1, 0], r_r[0, 0]))
                else:
                    sw_start_pos = p_r.copy()
                    sw_start_yaw = float(np.arctan2(r_r[1, 0], r_r[0, 0]))
                    st_hold_yaw_l = float(np.arctan2(r_l[1, 0], r_l[0, 0]))

            s_sign = 1.0 if swing_side == "left" else -1.0
            in_ds = tau_step < (ds_frac * step_T)
            p_st = p_r if swing_side == "left" else p_l

            v_des = v_fwd_target if step_num >= 1 else 0.24
            step_dx = v_des * step_T
            x_off = step_dx / (b_val - 1.0)
            dcm_xy = p_com[:2] + v_com[:2] / omega

            if in_ds:
                phase_sw = 0.0
                if swing_side == "left":
                    sw_start_pos = p_l.copy()
                    sw_start_yaw = float(np.arctan2(r_l[1, 0], r_l[0, 0]))
                    st_hold_yaw_r = float(np.arctan2(r_r[1, 0], r_r[0, 0]))
                else:
                    sw_start_pos = p_r.copy()
                    sw_start_yaw = float(np.arctan2(r_r[1, 0], r_r[0, 0]))
                    st_hold_yaw_l = float(np.arctan2(r_l[1, 0], r_l[0, 0]))
            else:
                phase_sw = min(1.0, (tau_step - ds_frac * step_T) / ((1.0 - ds_frac) * step_T))

            if phase_sw < 0.85:
                # Target landing rotated into scheduled SE(2) heading frame
                psi_land, _ = yaw_schedule(min(duration_s, t + (1.0 - phase_sw) * (1.0 - ds_frac) * step_T))
                sw_tgt_yaw = psi_land
                tgt_xy_raw = dcm_xy - x_off * u_fwd + (s_sign * y_off_nom) * u_lat
                rel = tgt_xy_raw - p_st[:2]
                dx_loc = float(np.clip(np.dot(rel, u_fwd), -0.06, 0.33))
                y_a, y_b = s_sign * 0.145, s_sign * 0.31
                dy_loc = float(np.clip(np.dot(rel, u_lat), min(y_a, y_b), max(y_a, y_b)))
                sw_tgt_xy = p_st[:2] + dx_loc * u_fwd + dy_loc * u_lat

        # Centroidal ZMP & DCM reference in world XY aligned to active heading
        if in_ds:
            w_l_share, w_r_share = 0.5, 0.5
            p_zmp_st = 0.5 * (p_l + p_r)
        elif swing_side == "left":
            w_l_share, w_r_share = 0.0, 1.0
            p_zmp_st = p_r.copy()
        else:
            w_l_share, w_r_share = 1.0, 0.0
            p_zmp_st = p_l.copy()

        dcm_xy = p_com[:2] + v_com[:2] / omega
        if step < settle_steps:
            zmp_ref_xy = p_zmp_st[:2] - 0.01 * u_fwd + (0.045 if float(np.dot(dcm_xy - 0.5 * (p_l[:2] + p_r[:2]), u_lat)) > -0.055 else -0.02) * u_lat
        elif in_ds:
            zmp_ref_xy = p_zmp_st[:2] - 0.01 * u_fwd
        else:
            step_dx = (v_fwd_target if step_num >= 1 else 0.24) * step_T
            x_off = step_dx / (b_val - 1.0)
            exp_tau = float(np.exp(omega * tau_step))
            cent_inward = 0.14 * (v_fwd_target * omega_yaw) / (g / z_nom)
            dcm_nom_xy = p_zmp_st[:2] + (x_off * exp_tau) * u_fwd + (s_sign * y_off_nom * exp_tau + cent_inward) * u_lat
            zmp_ref_xy = p_zmp_st[:2] + k_dcm * (dcm_xy - dcm_nom_xy)

        # Bound ZMP strictly within active sole heading polygon
        r_heading_2d = np.column_stack([u_fwd, u_lat])
        zmp_rel_h = r_heading_2d.T @ (zmp_ref_xy - p_zmp_st[:2])
        if in_ds:
            zmp_rel_h[0] = float(np.clip(zmp_rel_h[0], -0.09, 0.09))
            zmp_rel_h[1] = float(np.clip(zmp_rel_h[1], -0.14, 0.14))
        else:
            zmp_rel_h[0] = float(np.clip(zmp_rel_h[0], -0.10, 0.10))
            zmp_rel_h[1] = float(np.clip(zmp_rel_h[1], -0.035, 0.035))
        zmp_ref_xy = p_zmp_st[:2] + r_heading_2d @ zmp_rel_h

        fz_des = total_mass * (g + 420.0 * (z_nom - p_com[2]) - 42.0 * v_com[2])
        fz_des = float(np.clip(fz_des, 0.35 * total_mass * g, 2.15 * total_mass * g))
        f_xy_des = total_mass * (g / z_nom) * (p_com[:2] - zmp_ref_xy)
        f_mag = float(np.hypot(f_xy_des[0], f_xy_des[1]))
        if f_mag > 280.0:
            f_xy_des = f_xy_des * (280.0 / f_mag)

        w_total = np.array([float(f_xy_des[0]), float(f_xy_des[1]), fz_des, 0.0, 0.0, 0.0])

        r_pelv_des = rot_z(psi_cmd) @ r_pitch_lean
        e_rot = mat_to_rotvec_err(r_pelv_des, pelv_mat)
        tau_pelv = 720.0 * e_rot - 48.0 * pelv_w

        ctrl = np.zeros(model.nu)
        for i in upper_act:
            q_err = q_init[i] - data.qpos[act_qidx[i]]
            dq = data.qvel[act_vidx[i]]
            ctrl[i] = 180.0 * q_err - 16.0 * dq + data.qfrc_bias[act_vidx[i]]

        for side in ("left", "right"):
            is_left = side == "left"
            v_idx = l_leg_v if is_left else r_leg_v
            a_idx = l_leg_act if is_left else r_leg_act
            j_p = (jac_p_l if is_left else jac_p_r)[:, v_idx]
            j_r = (jac_r_l if is_left else jac_r_r)[:, v_idx]
            j_6 = np.vstack([j_p, j_r])
            p_cur = p_l if is_left else p_r
            v_cur = v_l if is_left else v_r
            r_cur = r_l if is_left else r_r
            w_cur = w_l if is_left else w_r
            w_share = w_l_share if is_left else w_r_share

            if w_share > 0.0:
                w_st = w_total * w_share
                w_st[3:6] = w_share * tau_pelv

                st_yaw = st_hold_yaw_l if is_left else st_hold_yaw_r
                e_f = mat_to_rotvec_err(rot_z(st_yaw), r_cur)
                w_st[3:6] -= (180.0 * e_f - 18.0 * w_cur)

                # Rotate ZMP COP offset into sole-local frame, clip, then transform moment back
                d_local = r_cur[:2, :2].T @ (zmp_ref_xy - p_cur[:2])
                dx_s = float(np.clip(d_local[0], -0.09, 0.09))
                dy_s = float(np.clip(d_local[1], -0.035, 0.035))
                m_cop_local = np.array([+w_st[2] * dy_s, -w_st[2] * dx_s, 0.0])
                w_st[3:6] += r_cur @ m_cop_local

                ctrl[a_idx] = data.qfrc_bias[v_idx] - j_6.T @ w_st
            else:
                s = phase_sw
                sw_dur = (1.0 - ds_frac) * step_T
                h_s = 3.0 * s ** 2 - 2.0 * s ** 3
                dh_dt = (6.0 * s * (1.0 - s)) / sw_dur

                sw_xy = sw_start_pos[:2] + (sw_tgt_xy - sw_start_pos[:2]) * h_s
                sw_vxy = (sw_tgt_xy - sw_start_pos[:2]) * dh_dt
                z_touch = -0.005
                sw_z = sw_start_pos[2] + (z_touch - sw_start_pos[2]) * h_s + swing_clear * (np.sin(np.pi * s) ** 2)
                sw_vz = (z_touch - sw_start_pos[2]) * dh_dt + swing_clear * (np.pi / sw_dur) * np.sin(2.0 * np.pi * s)

                pos_err = np.array([sw_xy[0], sw_xy[1], sw_z]) - p_cur
                vel_err = np.array([sw_vxy[0], sw_vxy[1], sw_vz]) - v_cur
                f_sw = np.array([2000.0, 2000.0, 2700.0]) * pos_err + np.array([85.0, 85.0, 105.0]) * vel_err

                d_yaw = wrap_angle_diff(sw_tgt_yaw, sw_start_yaw)
                sw_yaw_des = sw_start_yaw + d_yaw * h_s
                e_rot_sw = mat_to_rotvec_err(rot_z(sw_yaw_des), r_cur)
                m_sw = 240.0 * e_rot_sw - 18.0 * w_cur
                ctrl[a_idx] = data.qfrc_bias[v_idx] + j_6.T @ np.concatenate([f_sw, m_sw])

        ctrl = np.clip(ctrl, model.actuator_ctrlrange[:, 0], model.actuator_ctrlrange[:, 1])
        data.ctrl[:] = ctrl
        knee_trq_hist.append(float(max(abs(ctrl[l_knee_id]), abs(ctrl[r_knee_id]))))

        if verbose and step % 250 == 0:
            print(
                f"t={t:4.2f} X={data.qpos[0]:+.3f} Y={data.qpos[1]:+.3f} "
                f"Yaw={np.rad2deg(yaw_pelv):+5.1f}deg (Ref {np.rad2deg(psi_cmd):+5.1f}) "
                f"R={np.rad2deg(roll_pelv):+5.1f} P={np.rad2deg(pitch_pelv):+5.1f}"
            )
        mujoco.mj_step(model, data)

    t_arr = np.array(t_hist)
    x_arr = np.array(x_hist)
    y_arr = np.array(y_hist)
    yaw_arr = np.unwrap(np.deg2rad(np.array(yaw_hist))) * (180.0 / np.pi)
    yaw_ref_arr = np.array(yaw_ref_hist)
    path_len_m = float(np.sum(np.hypot(np.diff(x_arr), np.diff(y_arr))))
    final_yaw_deg = float(yaw_arr[-1])
    yaw_track_rms_deg = float(np.sqrt(np.mean((yaw_arr - yaw_ref_arr) ** 2)))
    roll_rms = float(np.sqrt(np.mean(np.array(roll_hist) ** 2)))
    pitch_rms = float(np.sqrt(np.mean(np.array(pitch_hist) ** 2)))
    peak_knee_nm = float(np.max(knee_trq_hist))
    peak_l_grf = float(np.max(l_grf_hist))
    peak_r_grf = float(np.max(r_grf_hist))
    turned_90_clean = bool((not fallen) and (final_yaw_deg >= 90.0) and (path_len_m >= 1.8))

    target_yaw_deg = float(np.rad2deg(yaw_schedule(duration_s)[0]))
    print(f"Total Simulated Time        : {t_arr[-1]:.2f} s ({len(t_arr)} physics steps)")
    print(f"Skyhook External Force      : 0.0 N (Strictly Disabled)")
    print(f"Curved Path Length Walked   : {path_len_m:.3f} m -> End ({x_arr[-1]:+.2f}, {y_arr[-1]:+.2f}) m")
    print(f"Cumulative Heading Turn Yaw : {final_yaw_deg:+.1f} deg (Target +{target_yaw_deg:.1f} deg, RMS {yaw_track_rms_deg:.2f} deg)")
    print(f"Pelvis Attitude RMS (R / P) : {roll_rms:.2f} deg / {pitch_rms:.2f} deg")
    print(f"Peak Foot GRF (L / R)       : {peak_l_grf:.1f} N / {peak_r_grf:.1f} N")
    print(f"Peak Knee Torque            : {peak_knee_nm:.1f} Nm (Class-Gamma Limit 220 Nm)")
    print(f">=90-Deg Corner Turn Status : {'PASSED' if turned_90_clean else 'FAILED'}")

    telemetry = {
        "module": "simulate_turning_walk_mujoco.py",
        "mujoco_version": mujoco.__version__,
        "skyhook_force_n": 0.0,
        "duration_s": round(float(t_arr[-1]), 3),
        "path_length_m": round(path_len_m, 3),
        "end_x_m": round(float(x_arr[-1]), 3),
        "end_y_m": round(float(y_arr[-1]), 3),
        "target_yaw_deg": round(target_yaw_deg, 1),
        "final_yaw_deg": round(final_yaw_deg, 2),
        "yaw_tracking_rms_deg": round(yaw_track_rms_deg, 2),
        "roll_rms_deg": round(roll_rms, 2),
        "pitch_rms_deg": round(pitch_rms, 2),
        "peak_left_grf_n": round(peak_l_grf, 1),
        "peak_right_grf_n": round(peak_r_grf, 1),
        "peak_knee_torque_nm": round(peak_knee_nm, 1),
        "completed_without_fall": bool(not fallen),
        "achieved_90deg_turn": turned_90_clean,
    }
    json_path = os.path.join(base_dir, "figure05_turning_telemetry.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(telemetry, f, indent=2)
    print(f"[SAVED] Telemetry JSON -> {json_path}")

    # 4-Panel Engineering Chart
    plt.style.use("dark_background")
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.patch.set_facecolor("#090d16")

    # Panel 1: Top-down 2D Curved Path + Footprints
    ax = axes[0, 0]
    ax.set_facecolor("#0f172a")
    lf_arr = np.array(lf_xy_hist)
    rf_arr = np.array(rf_xy_hist)
    ax.plot(x_arr, y_arr, color="#a855f7", lw=2.6, label=f"Pelvis CoM Path ({path_len_m:.2f} m)")
    ax.plot(lf_arr[:, 0], lf_arr[:, 1], color="#38bdf8", lw=1.3, alpha=0.8, label="Left Foot Path")
    ax.plot(rf_arr[:, 0], rf_arr[:, 1], color="#f97316", lw=1.3, ls="--", alpha=0.8, label="Right Foot Path")
    for idx_q in range(0, len(t_arr), 400):
        psi_q = np.deg2rad(yaw_arr[idx_q])
        ax.quiver(x_arr[idx_q], y_arr[idx_q], np.cos(psi_q), np.sin(psi_q),
                  color="#10b981", scale=12, width=0.005, headwidth=3.5)
    ax.set_title("1. Top-Down SE(2) Aisle Corner Trajectory X-Y", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("World X [m]")
    ax.set_ylabel("World Y [m]")
    ax.set_aspect("equal", adjustable="datalim")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper left")

    # Panel 2: Yaw Heading Angle vs Target
    ax = axes[0, 1]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, yaw_ref_arr, color="#94a3b8", ls="--", lw=1.8, label=f"Scheduled Yaw Ref (+{target_yaw_deg:.0f} deg)")
    ax.plot(t_arr, yaw_arr, color="#10b981", lw=2.2, label=f"Measured Yaw (End {final_yaw_deg:.1f} deg)")
    ax.axhline(90.0, color="#facc15", ls=":", lw=1.2, label="90 deg Orthogonal Corner")
    ax.set_title("2. Heading Steering Tracking Yaw(t)", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Heading Angle [deg]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper left")

    # Panel 3: Roll & Pitch Stability During Continuous Turn
    ax = axes[1, 0]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, roll_hist, color="#22d3ee", lw=1.8, label=f"Roll (RMS {roll_rms:.2f} deg)")
    ax.plot(t_arr, pitch_hist, color="#f43f5e", lw=1.8, label=f"Pitch (RMS {pitch_rms:.2f} deg)")
    ax.axhline(0.0, color="#64748b", lw=1.0, ls=":")
    ax.set_title("3. Skyhook-Free Turning Pelvis Attitude", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Orientation [deg]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    # Panel 4: Floor GRFs
    ax = axes[1, 1]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, l_grf_hist, color="#38bdf8", lw=1.4, alpha=0.9, label=f"Left GRF (Peak {peak_l_grf:.0f} N)")
    ax.plot(t_arr, r_grf_hist, color="#f97316", lw=1.4, alpha=0.9, label=f"Right GRF (Peak {peak_r_grf:.0f} N)")
    ax.axhline(total_mass * g, color="#10b981", ls="--", lw=1.2, label=f"Robot Weight ({total_mass*g:.0f} N)")
    ax.set_title("4. Alternating Floor Contact GRF Along Curve", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Vertical GRF [N]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    fig.suptitle(
        f"FIGURE 05 | Skyhook-Free MuJoCo 3.6 Curved {final_yaw_deg:.1f}-Deg Aisle Turn "
        f"(Path {path_len_m:.2f} m, Roll RMS {roll_rms:.2f} deg)",
        fontsize=14,
        fontweight="bold",
        color="#ffffff",
    )
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_png = os.path.join(base_dir, "figure05_mujoco_turning_benchmark.png")
    plt.savefig(out_png, dpi=180, facecolor=fig.get_facecolor())
    plt.close()
    print(f"[SAVED] Benchmark Plot -> {out_png}")

    if not turned_90_clean:
        raise AssertionError(
            f"Curved turn walk failed (yaw={final_yaw_deg:.1f}deg, path={path_len_m:.2f}m, fallen={fallen})"
        )


if __name__ == "__main__":
    run_turning_walk_simulation()
