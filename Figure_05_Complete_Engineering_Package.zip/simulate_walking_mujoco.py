"""
Figure 05 - Skyhook-Free MuJoCo 3.6 Dynamic Bipedal Walking Controller
====================================================================
Authors: Santiago Maroto (Lead Researcher) & Project Figure 05 Engineering Group
Target: Kyle Edelberg & Brett Adcock, Figure AI

Architecture (100% Pure Rigid-Body Physics, Zero Skyhook Forces):
1. Strict skyhook prohibition: `data.qfrc_applied[:] = 0.0` at every 500 Hz step.
2. Analytic Englsberger Divergent Component of Motion (DCM / Capture Point)
   deadbeat step-to-step foot placement law in both sagittal (X) and lateral (Y)
   planes for sustained dynamic locomotion over flat ground.
3. Centroidal Whole-Body Control (WBC) stance-leg contact wrench projection:
   tau_stance = S * (qfrc_bias - J_st^T * w_st) with ZMP sole polygon bounds.
4. Operational-space 6-DOF swing-foot impedance + velocity feedforward (J_sw^T * F_sw)
   tracking cycloidal 3D foot clearance and flat landing orientation.
5. Direct MuJoCo contact-frame reaction force measurement (`mj_contactForce`)
   verifying alternating single-support flight/stance foot loading (~0 N <-> ~540 N).
"""

import json
import os
import mujoco
import numpy as np
import matplotlib.pyplot as plt

from figure05_mujoco_common import (
    build_actuator_mappings,
    mat_to_rotvec_err,
    quat_to_roll_pitch_yaw,
    setup_crouched_biped,
    sum_support_grfs,
)  # mat_to_rotvec_err re-exported for downstream callers


def run_walking_simulation():
    print("=================================================================")
    print("FIGURE 05: SKYHOOK-FREE MUJOCO 3.6 DYNAMIC BIPEDAL WALKING")
    print("=================================================================")

    base_dir = os.path.dirname(os.path.abspath(__file__))
    xml_path = os.path.join(base_dir, "figure05_mujoco.xml")
    model = mujoco.MjModel.from_xml_path(xml_path)
    data = mujoco.MjData(model)

    dt = model.opt.timestep
    g = 9.80665
    total_mass = float(np.sum(model.body_mass))

    setup_crouched_biped(model, data)

    # Actuator & DOF mappings via shared helper
    maps = build_actuator_mappings(model)
    act_names = maps["act_names"]
    act_qidx = maps["act_qidx"]
    act_vidx = maps["act_vidx"]
    q_init = np.array([data.qpos[idx] for idx in act_qidx])
    idx_map = maps["idx_map"]

    l_leg_v = maps["l_leg_v"]
    r_leg_v = maps["r_leg_v"]
    l_leg_act = maps["l_leg_act"]
    r_leg_act = maps["r_leg_act"]

    l_site = model.site("left_foot_contact").id
    r_site = model.site("right_foot_contact").id
    l_body = model.body("left_ankle").id
    r_body = model.body("right_ankle").id
    chest_body_id = model.body("upper_chest").id
    floor_geom = model.geom("floor").id

    # Pre-allocated Jacobians
    jac_com = np.zeros((3, model.nv))
    jac_lp = np.zeros((3, model.nv))
    jac_lr = np.zeros((3, model.nv))
    jac_rp = np.zeros((3, model.nv))
    jac_rr = np.zeros((3, model.nv))

    # Englsberger DCM Walking Parameters
    duration = 8.0
    n_steps = int(round(duration / dt))
    z_c = 0.855
    omega = np.sqrt(g / z_c)
    t_step = 0.44
    ds_frac = 0.20
    vx_des = 0.65
    w_step = 0.21
    h_lift = 0.065
    t_stand = 0.60

    by_nom = w_step / (np.exp(omega * t_step) + 1.0)

    # Telemetry arrays
    t_log = np.zeros(n_steps)
    com_x_log = np.zeros(n_steps)
    com_y_log = np.zeros(n_steps)
    pelvis_z_log = np.zeros(n_steps)
    vx_log = np.zeros(n_steps)
    roll_log = np.zeros(n_steps)
    pitch_log = np.zeros(n_steps)
    l_foot_z_log = np.zeros(n_steps)
    r_foot_z_log = np.zeros(n_steps)
    fz_l_log = np.zeros(n_steps)
    fz_r_log = np.zeros(n_steps)
    knee_tau_l_log = np.zeros(n_steps)
    knee_tau_r_log = np.zeros(n_steps)

    step_idx = -1
    stance_side = 1
    sw_start_pos = data.site_xpos[r_site].copy()
    prev_pdes = sw_start_pos.copy()
    max_skyhook_norm = 0.0
    cf_buf = np.zeros(6)

    # Mid-stride lateral push disturbance parameters (120 ms Single-Support shove)
    push_start_t = 3.34
    push_end_t = 3.46
    push_force_y = 70.0  # N (8.4 N*s mid-stride impulse)

    print(f"[*] Robot Mass: {total_mass:.2f} kg | Skyhook: 0.0 N | Omega0: {omega:.3f} rad/s")
    print(f"[*] Running {duration:.1f} s dynamic bipedal gait + {push_force_y:.0f} N mid-stride push @ {push_start_t:.2f}s...")

    for k in range(n_steps):
        t = k * dt
        data.qfrc_applied[:] = 0.0
        data.xfrc_applied[chest_body_id, 1] = push_force_y if (push_start_t <= t < push_end_t) else 0.0
        max_skyhook_norm = max(max_skyhook_norm, float(np.linalg.norm(data.qfrc_applied)))

        mujoco.mj_jacSubtreeCom(model, data, jac_com, 1)
        mujoco.mj_jacSite(model, data, jac_lp, jac_lr, l_site)
        mujoco.mj_jacSite(model, data, jac_rp, jac_rr, r_site)

        com = data.subtree_com[1].copy()
        com_vel = jac_com @ data.qvel
        dcm = com[:2] + com_vel[:2] / omega

        p_l = data.site_xpos[l_site].copy()
        p_r = data.site_xpos[r_site].copy()
        v_l = jac_lp @ data.qvel
        v_r = jac_rp @ data.qvel
        r_l = data.site_xmat[l_site].reshape(3, 3)
        r_r = data.site_xmat[r_site].reshape(3, 3)

        roll, pitch, yaw = quat_to_roll_pitch_yaw(data.qpos[3:7])
        droll, dpitch, dyaw = data.qvel[3:6]

        # Gait State Machine
        if t < t_stand:
            s = t / t_stand
            smooth = 0.5 * (1.0 - np.cos(np.pi * s))
            c_tgt = np.array([
                0.5 * (p_l[0] + p_r[0]) + 0.025 * smooth,
                (p_l[1] - by_nom) * smooth,
                z_c,
            ])
            alpha_l = 0.5 + 0.45 * smooth
            alpha_r = 1.0 - alpha_l
            swing = None
            vx_cmd = 0.0
            bx_cmd = 0.0
        else:
            tw = t - t_stand
            new_step = int(tw // t_step)
            phi = (tw % t_step) / t_step
            if new_step != step_idx:
                step_idx = new_step
                stance_side = 1 if (step_idx % 2 == 0) else -1
                sw_start_pos = (p_r if stance_side == 1 else p_l).copy()
                sw_start_pos[2] = 0.0
                prev_pdes = sw_start_pos.copy()

            vx_cmd = vx_des * np.clip(tw / 1.0, 0.25, 1.0)
            bx_cmd = (vx_cmd * t_step) / (np.exp(omega * t_step) - 1.0)

            if phi < ds_frac:
                s = phi / ds_frac
                smooth = 0.5 * (1.0 - np.cos(np.pi * s))
                if step_idx == 0:
                    alpha_l = 0.95 + 0.05 * smooth
                else:
                    alpha_l = smooth if stance_side == 1 else (1.0 - smooth)
                alpha_r = 1.0 - alpha_l
                swing = None
            else:
                alpha_l = 1.0 if stance_side == 1 else 0.0
                alpha_r = 1.0 - alpha_l
                swing = "R" if stance_side == 1 else "L"
                s_sw = (phi - ds_frac) / (1.0 - ds_frac)

        # Centroidal Vertical Force
        fz_tot = total_mass * (g + 160.0 * (z_c - com[2]) - 26.0 * com_vel[2])
        fz_tot = float(np.clip(fz_tot, 180.0, 1100.0))

        # Horizontal GRF & CoP inside support polygon
        if t < t_stand:
            f_xy = total_mass * np.array([
                75.0 * (c_tgt[0] - com[0]) - 13.0 * com_vel[0],
                110.0 * (c_tgt[1] - com[1]) - 14.0 * com_vel[1],
            ])
        elif swing is None:
            p_cop_des = alpha_l * p_l[:2] + alpha_r * p_r[:2]
            f_xy = total_mass * np.array([
                4.0 * (vx_cmd - com_vel[0]),
                32.0 * (p_cop_des[1] - com[1]) - 6.0 * com_vel[1],
            ])
        else:
            p_st = p_l if stance_side == 1 else p_r
            cop_x = p_st[0] + np.clip(0.25 * (dcm[0] - (p_st[0] + bx_cmd)), -0.05, 0.08)
            cop_y = p_st[1] + np.clip(0.25 * (dcm[1] - (p_st[1] - stance_side * by_nom)), -0.03, 0.03)
            f_xy = total_mass * (omega**2) * np.array([com[0] - cop_x, com[1] - cop_y])
            f_xy = np.clip(f_xy, -180.0, 180.0)

        tau_trunk = np.array([
            -300.0 * roll - 32.0 * droll,
            -280.0 * pitch - 32.0 * dpitch,
            -90.0 * yaw - 12.0 * dyaw,
        ])

        fz_l = alpha_l * fz_tot
        fz_r = alpha_r * fz_tot

        w_l = np.zeros(6)
        w_r = np.zeros(6)
        if alpha_l > 0.01:
            w_l = np.array([
                alpha_l * f_xy[0],
                alpha_l * f_xy[1],
                fz_l,
                np.clip(alpha_l * tau_trunk[0], -0.05 * fz_l, 0.05 * fz_l),
                np.clip(alpha_l * tau_trunk[1], -0.10 * fz_l, 0.10 * fz_l),
                alpha_l * tau_trunk[2],
            ])
        if alpha_r > 0.01:
            w_r = np.array([
                alpha_r * f_xy[0],
                alpha_r * f_xy[1],
                fz_r,
                np.clip(alpha_r * tau_trunk[0], -0.05 * fz_r, 0.05 * fz_r),
                np.clip(alpha_r * tau_trunk[1], -0.10 * fz_r, 0.10 * fz_r),
                alpha_r * tau_trunk[2],
            ])

        j_l = np.vstack([jac_lp, jac_lr])
        j_r = np.vstack([jac_rp, jac_rr])
        tau_gen = data.qfrc_bias.copy()
        if alpha_l > 0.01:
            tau_gen -= j_l.T @ w_l
        if alpha_r > 0.01:
            tau_gen -= j_r.T @ w_r

        tau_ctrl = np.array([tau_gen[idx] for idx in act_vidx])

        if swing is not None:
            p_st = p_l if stance_side == 1 else p_r
            s_sw_side = -1 if stance_side == 1 else 1
            tgt_x = np.clip(dcm[0] - bx_cmd, p_st[0] - 0.10, p_st[0] + 0.45)
            tgt_y = dcm[1] + s_sw_side * by_nom - 0.08 * com[1]
            if s_sw_side == -1:
                tgt_y = np.clip(tgt_y, p_st[1] - 0.33, p_st[1] - 0.15)
            else:
                tgt_y = np.clip(tgt_y, p_st[1] + 0.15, p_st[1] + 0.33)

            smooth_xy = 0.5 * (1.0 - np.cos(np.pi * s_sw))
            z_des = h_lift * np.sin(np.pi * s_sw) - 0.002 * (s_sw**2)
            p_des = np.array([
                sw_start_pos[0] + smooth_xy * (tgt_x - sw_start_pos[0]),
                sw_start_pos[1] + smooth_xy * (tgt_y - sw_start_pos[1]),
                z_des,
            ])
            v_des = (p_des - prev_pdes) / dt if s_sw > 0.01 else np.zeros(3)
            prev_pdes = p_des.copy()

            p_cur = p_r if swing == "R" else p_l
            v_cur = v_r if swing == "R" else v_l
            r_cur = r_r if swing == "R" else r_l
            w_cur = (jac_rr @ data.qvel) if swing == "R" else (jac_lr @ data.qvel)
            j_sw = j_r if swing == "R" else j_l
            sw_dofs = r_leg_v if swing == "R" else l_leg_v
            sw_acts = r_leg_act if swing == "R" else l_leg_act

            r_err = mat_to_rotvec_err(np.eye(3), r_cur)
            f_sw = np.concatenate([
                np.array([1500.0, 1500.0, 1900.0]) * (p_des - p_cur)
                + np.array([70.0, 70.0, 85.0]) * (v_des - v_cur),
                np.array([100.0, 130.0, 80.0]) * r_err
                - np.array([7.0, 9.0, 6.0]) * w_cur,
            ])
            tau_sw_full = data.qfrc_bias + j_sw.T @ f_sw
            for ai, vi in zip(sw_acts, sw_dofs):
                tau_ctrl[ai] = tau_sw_full[vi]

            st_acts = l_leg_act if stance_side == 1 else r_leg_act
            tau_ctrl[st_acts[0]] += 50.0 * yaw + 6.0 * dyaw
            tau_ctrl[st_acts[1]] += 110.0 * roll + 12.0 * droll
            tau_ctrl[st_acts[2]] += 100.0 * pitch + 11.0 * dpitch
        else:
            tau_ctrl[l_leg_act[1]] += 60.0 * roll + 7.0 * droll
            tau_ctrl[r_leg_act[1]] += 60.0 * roll + 7.0 * droll
            tau_ctrl[l_leg_act[2]] += 50.0 * pitch + 6.0 * dpitch
            tau_ctrl[r_leg_act[2]] += 50.0 * pitch + 6.0 * dpitch

        # Upper body + natural counter-arm swing
        q = np.array([data.qpos[idx] for idx in act_qidx])
        qd = np.array([data.qvel[idx] for idx in act_vidx])
        q_t = q_init.copy()
        arm_amp = 0.25 * np.clip(com_vel[0] / 0.55, 0.0, 1.2)
        q_t[idx_map["act_left_shoulder_pitch"]] = arm_amp * (-stance_side)
        q_t[idx_map["act_right_shoulder_pitch"]] = arm_amp * stance_side
        for i, name in enumerate(act_names):
            if not any(x in name for x in ["hip", "knee", "ankle"]):
                tau_ctrl[i] += 180.0 * (q_t[i] - q[i]) - 16.0 * qd[i]

        data.ctrl[:] = np.clip(
            tau_ctrl, model.actuator_ctrlrange[:, 0], model.actuator_ctrlrange[:, 1]
        )
        mujoco.mj_step(model, data)

        # Measure real MuJoCo vertical contact forces on Left vs Right soles
        fz_l_c, fz_r_c = sum_support_grfs(model, data, (floor_geom,), l_body, r_body)

        t_log[k] = t
        com_x_log[k] = com[0]
        com_y_log[k] = com[1]
        pelvis_z_log[k] = data.qpos[2]
        vx_log[k] = com_vel[0]
        roll_log[k] = np.rad2deg(roll)
        pitch_log[k] = np.rad2deg(pitch)
        l_foot_z_log[k] = p_l[2] * 100.0  # cm
        r_foot_z_log[k] = p_r[2] * 100.0  # cm
        fz_l_log[k] = fz_l_c
        fz_r_log[k] = fz_r_c
        knee_tau_l_log[k] = data.ctrl[idx_map["act_left_knee"]]
        knee_tau_r_log[k] = data.ctrl[idx_map["act_right_knee"]]

    steady_mask = t_log >= 2.0
    total_distance_m = float(com_x_log[-1] - com_x_log[0])
    mean_steady_vx = float(np.mean(vx_log[steady_mask]))
    rms_roll_steady = float(np.sqrt(np.mean(roll_log[steady_mask] ** 2)))
    rms_pitch_steady = float(np.sqrt(np.mean(pitch_log[steady_mask] ** 2)))
    max_foot_clearance_cm = float(max(np.max(l_foot_z_log), np.max(r_foot_z_log)))
    peak_knee_torque = float(max(np.max(np.abs(knee_tau_l_log)), np.max(np.abs(knee_tau_r_log))))
    min_pelvis_z = float(np.min(pelvis_z_log))
    survived_full = bool(min_pelvis_z > 0.75)

    post_push_mask = t_log >= push_start_t
    peak_roll_post_push = float(np.max(np.abs(roll_log[post_push_mask])))
    end_roll_deg = float(roll_log[-1])

    print(f"[+] Distance walked in {duration:.1f} s: {total_distance_m:.3f} m (Steady vx: {mean_steady_vx:.3f} m/s)")
    print(f"[+] Steady-state RMS Attitude (t>=2s): Roll={rms_roll_steady:.2f} deg | Pitch={rms_pitch_steady:.2f} deg")
    print(f"[+] Mid-Stride {push_force_y:.0f} N Push Recovery: Peak Roll={peak_roll_post_push:.1f} deg -> End Roll={end_roll_deg:+.1f} deg")
    print(f"[+] Max Swing Foot Clearance: {max_foot_clearance_cm:.2f} cm | Peak Knee Torque: {peak_knee_torque:.1f} Nm")
    print(f"[+] Min Pelvis Z: {min_pelvis_z:.3f} m | Upright Full Duration: {survived_full}")

    telemetry = {
        "engine": "MuJoCo 3.6.0",
        "controller": "Englsberger DCM Capture Point + Centroidal WBC + J_sw^T Impedance",
        "skyhook_force_n": max_skyhook_norm,
        "robot_mass_kg": round(total_mass, 2),
        "duration_s": duration,
        "step_period_s": t_step,
        "double_support_ratio": ds_frac,
        "distance_walked_m": round(total_distance_m, 3),
        "steady_state_speed_m_s": round(mean_steady_vx, 3),
        "steady_state_rms_roll_deg": round(rms_roll_steady, 2),
        "steady_state_rms_pitch_deg": round(rms_pitch_steady, 2),
        "mid_stride_push_n": push_force_y,
        "peak_roll_post_push_deg": round(peak_roll_post_push, 2),
        "max_foot_clearance_cm": round(max_foot_clearance_cm, 2),
        "peak_knee_torque_nm": round(peak_knee_torque, 1),
        "min_pelvis_height_m": round(min_pelvis_z, 3),
        "completed_without_fall": survived_full,
    }
    json_path = os.path.join(base_dir, "figure05_walking_telemetry.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(telemetry, f, indent=4)

    # Plot 2x2 Engineering Benchmark Figure
    plt.style.use("dark_background")
    fig, axs = plt.subplots(2, 2, figsize=(13.5, 8.8), gridspec_kw={"hspace": 0.36, "wspace": 0.38})
    fig.patch.set_facecolor("#0f1419")

    # 1. Forward Progress & Velocity
    ax1 = axs[0, 0]
    ax1.set_facecolor("#151c24")
    l1, = ax1.plot(t_log, com_x_log, color="#00ffcc", lw=2.2, label="CoM X Displacement (m)")
    ax1_r = ax1.twinx()
    l2, = ax1_r.plot(t_log, vx_log, color="#ff9900", lw=1.4, alpha=0.85, label="Forward Velocity vx (m/s)")
    l3 = ax1_r.axhline(mean_steady_vx, color="#ff9900", ls=":", lw=1.2, label=f"Mean Steady vx ({mean_steady_vx:.2f} m/s)")
    ax1.set_title("1. Skyhook-Free Forward Locomotion Progress", color="white", fontweight="bold", pad=8)
    ax1.set_xlabel("Time (s)", color="#cccccc")
    ax1.set_ylabel("CoM X Distance (m)", color="#00ffcc")
    ax1_r.set_ylabel("Velocity vx (m/s)", color="#ff9900")
    ax1_r.set_ylim(-0.04, 0.56)
    ax1.grid(True, alpha=0.2)
    lines = [l1, l2, l3]
    ax1.legend(lines, [l.get_label() for l in lines], loc="upper left", fontsize=8.0, facecolor="#0f1419")

    # 2. Alternating Contact GRFs
    ax2 = axs[0, 1]
    ax2.set_facecolor("#151c24")
    ax2.plot(t_log, fz_l_log, color="#00d4ff", lw=1.3, alpha=0.9, label="Left Foot GRF Fz (N)")
    ax2.plot(t_log, fz_r_log, color="#ff44aa", lw=1.3, alpha=0.85, label="Right Foot GRF Fz (N)")
    ax2.set_title("2. Alternating Single/Double Support GRF (N)", color="white", fontweight="bold", pad=8)
    ax2.set_xlabel("Time (s)", color="#cccccc")
    ax2.set_ylabel("Vertical Ground Force (N)", color="#cccccc")
    ax2.set_ylim(-30, 1450)
    ax2.grid(True, alpha=0.2)
    ax2.legend(loc="upper right", fontsize=8.5, facecolor="#0f1419")

    # 3. Attitude Stability (Roll / Pitch) & Mid-Stride Push Disturbance
    ax3 = axs[1, 0]
    ax3.set_facecolor("#151c24")
    ax3.plot(t_log, roll_log, color="#00ffcc", lw=1.6, label=f"Pelvis Roll (RMS steady {rms_roll_steady:.2f} deg)")
    ax3.plot(t_log, pitch_log, color="#ffcc00", lw=1.6, label=f"Pelvis Pitch (RMS steady {rms_pitch_steady:.2f} deg)")
    ax3.axvspan(push_start_t, push_end_t, color="#ef4444", alpha=0.30, label=f"{push_force_y:.0f} N Mid-Stride Shove ({peak_roll_post_push:.1f} deg peak)")
    ax3.axhline(0.0, color="#666666", ls="--", lw=0.9)
    ax3.set_title("3. Floating-Base Attitude & Mid-Stride Push Recovery", color="white", fontweight="bold", pad=8)
    ax3.set_xlabel("Time (s)", color="#cccccc")
    ax3.set_ylabel("Pelvis Angle (deg)", color="#cccccc")
    ax3.grid(True, alpha=0.2)
    ax3.legend(loc="upper right", fontsize=8.0, facecolor="#0f1419")

    # 4. Swing Foot Clearance & Knee Actuator Torques
    ax4 = axs[1, 1]
    ax4.set_facecolor("#151c24")
    p1, = ax4.plot(t_log, l_foot_z_log, color="#00d4ff", lw=1.6, label="Left Foot Z Clearance (cm)")
    p2, = ax4.plot(t_log, r_foot_z_log, color="#ff44aa", lw=1.6, label="Right Foot Z Clearance (cm)")
    ax4_r = ax4.twinx()
    p3, = ax4_r.plot(t_log, knee_tau_l_log, color="#88ff44", lw=1.1, alpha=0.72, label="Left Knee Torque (Nm)")
    ax4.set_title("4. Swing Clearance (cm) & Knee Torque Load (Nm)", color="white", fontweight="bold", pad=8)
    ax4.set_xlabel("Time (s)", color="#cccccc")
    ax4.set_ylabel("Foot Elevation (cm)", color="#00d4ff")
    ax4_r.set_ylabel("Knee Torque (Nm)", color="#88ff44")
    ax4.set_ylim(-1.2, 8.2)
    ax4_r.set_ylim(-145, 75)
    ax4.grid(True, alpha=0.2)
    ax4.legend([p1, p2, p3], [p1.get_label(), p2.get_label(), p3.get_label()], loc="upper right", fontsize=8.0, facecolor="#0f1419")

    fig.suptitle(
        f"FIGURE 05 - SKYHOOK-FREE MUJOCO 3.6 WALK + 70 N MID-STRIDE PUSH ({total_distance_m:.2f} m in {duration:.1f} s | 0.0 N Skyhook)",
        fontsize=12.8,
        fontweight="bold",
        color="white",
        y=0.97,
    )
    out_png = os.path.join(base_dir, "figure05_mujoco_walking_benchmark.png")
    plt.savefig(out_png, dpi=220, bbox_inches="tight", facecolor="#0f1419")
    plt.close(fig)
    print(f"[+] Generated {out_png} & {json_path}")

    assert survived_full and total_distance_m >= 2.0, "Walking gait failed forward survival check!"


if __name__ == "__main__":
    run_walking_simulation()
