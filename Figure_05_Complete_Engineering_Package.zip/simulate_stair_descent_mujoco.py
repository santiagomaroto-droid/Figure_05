"""
Figure 05 - Skyhook-Free MuJoCo 3.6 Multi-Riser 2-Step Stair Descent & Regen Audit
===================================================================================
Authors: Santiago Maroto (Lead Researcher) & Project Figure 05 Engineering Group
Target: Kyle Edelberg & Brett Adcock, Figure AI

Architecture (100% Pure Rigid-Body Physics, Zero Skyhook Forces):
1. Strict skyhook prohibition: `data.qfrc_applied[:] = 0.0` at every 500 Hz step.
2. Two-riser descending industrial staircase injected into `figure05_mujoco.xml`:
   - Top Mezzanine : z = +0.140 m  (x <= 0.38 m)
   - Mid Tread     : z = +0.070 m  (0.38 m < x <= 0.84 m, 46 cm flat landing)
   - Factory Floor : z =  0.000 m  (x > 0.84 m)
3. Plateau-latched DCM foothold planner preventing sole straddling over either drop-off
   (`[x_k - 0.135, x_k + 0.135]`) and capping descent to one riser per stride (`2 -> 1 -> 0`).
4. Heel-clearing descending swing profile synchronized with COM-tracked pelvis lowering
   (`-14.0 cm` total descent) and damped impact absorption.
5. True 4-quadrant 29-actuator electromechanical power balance integrating motoring,
   eccentric braking work (`tau * qd < 0`), hot-copper I^2 R losses, and 800V 3-level
   GaN FCML net electrical regenerative energy recovery back into the DC bus.
"""

import json
import os

import matplotlib.pyplot as plt
import mujoco
import numpy as np

from figure05_mujoco_common import (
    build_actuator_mappings,
    mat_to_rotvec_err,
    quat_to_roll_pitch_yaw,
    setup_crouched_biped,
    sum_support_grfs,
)


def descent_stair_height(
    x: float,
    x_drop1: float = 0.38,
    x_drop2: float = 0.84,
    riser_h: float = 0.070,
) -> float:
    """Return exact descending staircase height Z [m] at sagittal coordinate X."""
    if x <= x_drop1:
        return 2.0 * riser_h
    if x <= x_drop2:
        return riser_h
    return 0.0


def descent_level_at(x: float, x_drop1: float = 0.38, x_drop2: float = 0.84) -> int:
    """Return discrete staircase plateau index {2: top deck, 1: mid tread, 0: floor}."""
    if x <= x_drop1:
        return 2
    if x <= x_drop2:
        return 1
    return 0


def stair_descent_swing_profile(
    s: float,
    z_start: float,
    z_land: float,
    swing_clear: float,
    sw_dur: float,
) -> tuple[float, float]:
    """
    Compute 6-DOF swing Z [m] & Vz [m/s] holding initial tread clearance across `s in [0, 0.22]`
    so the heel clears the step edge before descending onto the lower tread/floor.
    """
    stepping_down = z_start > z_land + 0.01
    z_touch = z_land - (0.001 if stepping_down else 0.003)
    if stepping_down:
        u_z = float(np.clip((s - 0.22) / 0.78, 0.0, 1.0))
        z_base = z_start + (z_touch - z_start) * (3.0 * u_z ** 2 - 2.0 * u_z ** 3)
        if 0.22 < s < 1.0:
            dz_base_dt = (z_touch - z_start) * (6.0 * u_z * (1.0 - u_z)) / (0.78 * sw_dur)
        else:
            dz_base_dt = 0.0
        arc = (swing_clear * 0.85) * (np.sin(np.pi * s) ** 2)
        darc_dt = (swing_clear * 0.85) * (np.pi / sw_dur) * np.sin(2.0 * np.pi * s)
    else:
        z_base = z_start + (z_touch - z_start) * (3.0 * s ** 2 - 2.0 * s ** 3)
        dz_base_dt = (z_touch - z_start) * (6.0 * s * (1.0 - s)) / sw_dur
        arc = swing_clear * (np.sin(np.pi * s) ** 2)
        darc_dt = swing_clear * (np.pi / sw_dur) * np.sin(2.0 * np.pi * s)

    return float(z_base + arc), float(dz_base_dt + darc_dt)


def compute_electromechanical_step_power(
    tau_arr: np.ndarray,
    qd_arr: np.ndarray,
    kt_n_arr: np.ndarray,
    rw_arr: np.ndarray,
    eta_inv: float = 0.9524,
) -> tuple[float, float, float, float]:
    """
    Compute 4-quadrant actuator electrical bus power [W] at one physics step.

    Returns `(p_mech_pos, p_mech_neg, p_cu_total, p_regen_net_bus)`:
    - `p_mech_pos`: positive motoring shaft power (W)
    - `p_mech_neg`: total eccentric braking mechanical power absorbed at joints (W)
    - `p_cu_total`: 3-phase hot-winding I^2 R losses across all actuators (W)
    - `p_regen_net_bus`: net electrical regenerative power returned into the 800V DC bus (W)
    """
    p_mech = tau_arr * qd_arr
    i_q = tau_arr / kt_n_arr
    p_cu = 1.5 * (i_q ** 2) * rw_arr
    p_pos = float(np.sum(np.maximum(p_mech, 0.0)))
    p_neg = float(np.sum(np.maximum(-p_mech, 0.0)))
    # Per-axis net DC bus regeneration during eccentric braking (eta_inv efficiency minus copper loss)
    p_regen_axis = np.where(p_mech < 0.0, np.maximum(0.0, (-p_mech) * eta_inv - p_cu), 0.0)
    return p_pos, p_neg, float(np.sum(p_cu)), float(np.sum(p_regen_axis))


def run_stair_descent_simulation(
    verbose: bool = False,
    riser_h: float = 0.070,
    x_drop1: float = 0.38,
    x_drop2: float = 0.84,
) -> dict:
    print("=================================================================")
    print("FIGURE 05: SKYHOOK-FREE MUJOCO 3.6 2-STEP -140 MM STAIR DESCENT")
    print("=================================================================")

    base_dir = os.path.dirname(os.path.abspath(__file__))
    xml_path = os.path.join(base_dir, "figure05_mujoco.xml")
    with open(xml_path, "r", encoding="utf-8") as f:
        xml_str = f.read()

    # Upper Mezzanine: X in [-1.60, x_drop1], height 2*riser_h (+0.140 m)
    x_min_deck = -1.60
    top_half = 0.5 * (x_drop1 - x_min_deck)
    top_cx = x_min_deck + top_half
    top_hz = riser_h

    # Middle Tread: X in [x_drop1, x_drop2], height riser_h (+0.070 m)
    mid_half = 0.5 * (x_drop2 - x_drop1)
    mid_cx = 0.5 * (x_drop1 + x_drop2)
    mid_hz = 0.5 * riser_h

    stairs_down_xml = (
        f'\n        <geom name="stair_top_deck" type="box" contype="1" conaffinity="1" '
        f'pos="{top_cx:.4f} 0.0 {top_hz:.5f}" '
        f'size="{top_half:.4f} 1.20 {top_hz:.5f}" '
        f'rgba="0.28 0.36 0.48 1.0" friction="1.0 0.005 0.0005"/>'
        f'\n        <geom name="stair_mid_tread" type="box" contype="1" conaffinity="1" '
        f'pos="{mid_cx:.4f} 0.0 {mid_hz:.5f}" '
        f'size="{mid_half:.4f} 1.20 {mid_hz:.5f}" '
        f'rgba="0.22 0.28 0.38 1.0" friction="1.0 0.005 0.0005"/>\n'
    )
    if "</worldbody>" not in xml_str:
        raise RuntimeError("Missing </worldbody> closing tag in figure05_mujoco.xml")
    xml_down = xml_str.replace("</worldbody>", stairs_down_xml + "    </worldbody>", 1)

    model = mujoco.MjModel.from_xml_string(xml_down)
    data = mujoco.MjData(model)

    dt = model.opt.timestep
    g = 9.80665
    total_mass = float(np.sum(model.body_mass))
    top_elev = 2.0 * riser_h

    setup_crouched_biped(model, data)
    # Place both feet cleanly on top of the +140 mm elevated mezzanine deck
    data.qpos[2] += top_elev
    data.qvel[:] = 0.0
    mujoco.mj_forward(model, data)

    maps = build_actuator_mappings(model)
    act_names = maps["act_names"]
    act_qidx = maps["act_qidx"]
    act_vidx = maps["act_vidx"]
    idx_map = maps["idx_map"]
    l_leg_v = maps["l_leg_v"]
    r_leg_v = maps["r_leg_v"]
    l_leg_act = maps["l_leg_act"]
    r_leg_act = maps["r_leg_act"]
    upper_act = maps["upper_act"]
    q_init = np.array([data.qpos[idx] for idx in act_qidx])

    # Build physical motor parameter vectors (Kt*N and hot 83 C winding resistance Rw) per actuator
    kt_n_list, rw_hot_list = [], []
    for name in act_names:
        if ("hip_pitch" in name) or ("knee" in name) or ("torso_pitch" in name):
            kt_n_list.append(0.185 * 18.0)   # Class Gamma (3.33 Nm/A)
            rw_hot_list.append(0.0553)       # Hot 83.2 C Cu winding resistance
        elif ("neck" in name) or ("wrist" in name):
            kt_n_list.append(0.080 * 10.0)   # Class Alpha (0.80 Nm/A)
            rw_hot_list.append(0.130)
        else:
            kt_n_list.append(0.125 * 14.0)   # Class Beta (1.75 Nm/A)
            rw_hot_list.append(0.078)
    kt_n_arr = np.array(kt_n_list)
    rw_hot_arr = np.array(rw_hot_list)

    l_site = model.site("left_foot_contact").id
    r_site = model.site("right_foot_contact").id
    l_body = model.body("left_ankle").id
    r_body = model.body("right_ankle").id
    support_geoms = {
        model.geom("floor").id,
        model.geom("stair_top_deck").id,
        model.geom("stair_mid_tread").id,
    }
    pelvis_id = model.body("pelvis").id

    jac_com = np.zeros((3, model.nv))
    jac_p_l = np.zeros((3, model.nv))
    jac_r_l = np.zeros((3, model.nv))
    jac_p_r = np.zeros((3, model.nv))
    jac_r_r = np.zeros((3, model.nv))

    # Gait & DCM parameters
    step_T = 0.42
    ds_frac = 0.16
    half_y = 0.105
    swing_clear = 0.080
    z_nom = 0.870
    omega = np.sqrt(g / z_nom)
    b_val = np.exp(omega * step_T)
    y_off_nom = (2.0 * half_y) / (b_val + 1.0)
    k_dcm = 1.45

    duration_s = 7.06
    n_steps = int(duration_s / dt)
    settle_steps = 140

    swing_side = "left"
    sw_start_pos = data.site_xpos[l_site].copy()
    v_x_target = 0.38
    sw_tgt_x = min(sw_start_pos[0] + 0.5 * v_x_target * step_T, x_drop1 - 0.145)
    sw_tgt_y = half_y
    latched_target_level = 2
    z_ground_smooth = top_elev

    l_knee_id = idx_map["act_left_knee"]
    r_knee_id = idx_map["act_right_knee"]

    t_hist, x_hist, z_hist = [], [], []
    roll_hist, pitch_hist = [], []
    lf_x_hist, rf_x_hist = [], []
    lf_z_hist, rf_z_hist = [], []
    l_grf_hist, r_grf_hist = [], []
    p_mech_pos_hist, p_mech_neg_hist, p_regen_bus_hist = [], [], []
    knee_trq_hist = []
    e_cu_j = 0.0
    e_motor_mech_j = 0.0
    e_neg_mech_j = 0.0
    e_regen_bus_j = 0.0
    fallen = False

    r_pelv_des = np.array([
        [np.cos(0.035), 0.0, np.sin(0.035)],
        [0.0, 1.0, 0.0],
        [-np.sin(0.035), 0.0, np.cos(0.035)],
    ])
    r_flat = np.eye(3)

    for step in range(n_steps):
        t = step * dt
        mujoco.mj_forward(model, data)

        # Strictly zero skyhook forces
        data.qfrc_applied[:] = 0.0

        p_l = data.site_xpos[l_site].copy()
        p_r = data.site_xpos[r_site].copy()
        r_l = data.site_xmat[l_site].reshape(3, 3)
        r_r = data.site_xmat[r_site].reshape(3, 3)

        mujoco.mj_jacSubtreeCom(model, data, jac_com, pelvis_id)
        p_com = data.subtree_com[pelvis_id].copy()
        v_com = jac_com @ data.qvel

        mujoco.mj_jacSite(model, data, jac_p_l, jac_r_l, l_site)
        mujoco.mj_jacSite(model, data, jac_p_r, jac_r_r, r_site)
        v_l = jac_p_l @ data.qvel
        w_l = jac_r_l @ data.qvel
        v_r = jac_p_r @ data.qvel
        w_r = jac_r_r @ data.qvel

        pelv_mat = data.body("pelvis").xmat.reshape(3, 3)
        pelv_w = data.qvel[3:6].copy()
        roll_pelv, pitch_pelv, _ = quat_to_roll_pitch_yaw(data.qpos[3:7])

        l_grf, r_grf = sum_support_grfs(model, data, support_geoms, l_body, r_body)

        t_hist.append(t)
        x_hist.append(float(data.qpos[0]))
        z_hist.append(float(data.qpos[2]))
        roll_hist.append(float(np.rad2deg(roll_pelv)))
        pitch_hist.append(float(np.rad2deg(pitch_pelv)))
        lf_x_hist.append(float(p_l[0]))
        rf_x_hist.append(float(p_r[0]))
        lf_z_hist.append(float(p_l[2]))
        rf_z_hist.append(float(p_r[2]))
        l_grf_hist.append(l_grf)
        r_grf_hist.append(r_grf)

        local_floor = min(p_l[2], p_r[2])
        if data.qpos[2] - local_floor < 0.45:
            fallen = True
            print(f"[ABORT] Fall detected at t={t:.2f}s Z_pel={data.qpos[2]:.3f}m")
            break

        tau_step = 0.0
        step_num = 0
        if step < settle_steps:
            in_ds = True
            phase_sw = 0.0
            s_sign = 1.0
            latched_target_level = 2
            if step == settle_steps - 1:
                sw_start_pos = p_l.copy()
                sw_tgt_x = min(p_r[0] + 0.14, x_drop1 - 0.145)
                sw_tgt_y = p_r[1] + 2.0 * half_y
        else:
            step_idx = step - settle_steps
            ticks_per_step = int(step_T / dt)
            step_num = step_idx // ticks_per_step
            tau_step = (step_idx % ticks_per_step) * dt
            if step_idx % ticks_per_step == 0 and step_idx > 0:
                swing_side = "right" if swing_side == "left" else "left"
                sw_start_pos = p_l.copy() if swing_side == "left" else p_r.copy()

            s_sign = 1.0 if swing_side == "left" else -1.0
            in_ds = tau_step < (ds_frac * step_T)
            p_st = p_r if swing_side == "left" else p_l

            v_des = v_x_target if step_num >= 1 else 0.25
            step_dx = v_des * step_T
            x_off = step_dx / (b_val - 1.0)
            dcm_x = p_com[0] + v_com[0] / omega
            dcm_y = p_com[1] + v_com[1] / omega

            if in_ds:
                phase_sw = 0.0
                sw_start_pos = p_l.copy() if swing_side == "left" else p_r.copy()
                sw_lvl = descent_level_at(float(sw_start_pos[0]), x_drop1, x_drop2)
                st_lvl = descent_level_at(float(p_st[0]), x_drop1, x_drop2)
                x_end_pred = (
                    p_st[0]
                    + (dcm_x - p_st[0]) * np.exp(omega * (1.0 - ds_frac) * step_T)
                    - x_off
                )

                # Latch descending staircase level in double support only (max -1 riser per stride)
                if sw_lvl == 0 or (
                    sw_lvl == 1 and (st_lvl == 0 or x_end_pred >= x_drop2 - 0.125 or p_st[0] >= x_drop2 - 0.16)
                ):
                    latched_target_level = 0
                elif st_lvl == 0 and sw_lvl == 2:
                    latched_target_level = 1
                elif sw_lvl == 1 or st_lvl == 1 or (x_end_pred >= x_drop1 - 0.125) or (p_st[0] >= x_drop1 - 0.16):
                    latched_target_level = 1
                else:
                    latched_target_level = 2
            else:
                phase_sw = min(1.0, (tau_step - ds_frac * step_T) / ((1.0 - ds_frac) * step_T))

            if phase_sw < 0.85:
                tgt_x_raw = dcm_x - x_off
                if latched_target_level == 2:
                    x_min = p_st[0] - 0.06
                    x_max = max(x_min + 0.02, x_drop1 - 0.140)
                elif latched_target_level == 1:
                    x_min = max(x_drop1 + 0.135, p_st[0] - 0.06)
                    x_max = max(x_min + 0.02, min(x_drop2 - 0.140, p_st[0] + 0.34))
                else:
                    x_min = max(x_drop2 + 0.135, p_st[0] - 0.06)
                    x_max = max(x_min + 0.04, p_st[0] + 0.35)
                sw_tgt_x = float(np.clip(tgt_x_raw, x_min, x_max))

                tgt_y_raw = dcm_y + s_sign * y_off_nom - 0.15 * p_com[1]
                y_a = p_st[1] + s_sign * 0.14
                y_b = p_st[1] + s_sign * 0.29
                sw_tgt_y = float(np.clip(tgt_y_raw, min(y_a, y_b), max(y_a, y_b)))

        p_l_xy, p_r_xy = p_l[:2], p_r[:2]
        if in_ds:
            w_l_share, w_r_share = 0.5, 0.5
            p_zmp_st = 0.5 * (p_l + p_r)
        elif swing_side == "left":
            w_l_share, w_r_share = 0.0, 1.0
            p_zmp_st = p_r.copy()
        else:
            w_l_share, w_r_share = 1.0, 0.0
            p_zmp_st = p_l.copy()

        dcm_x = p_com[0] + v_com[0] / omega
        dcm_y = p_com[1] + v_com[1] / omega

        if step < settle_steps:
            zmp_ref_x = p_zmp_st[0] - 0.015
            zmp_ref_y = 0.045 if dcm_y > -0.055 else -0.02
        elif in_ds:
            zmp_ref_x = p_zmp_st[0] - 0.01
            zmp_ref_y = p_zmp_st[1]
        else:
            step_dx = (v_x_target if step_num >= 1 else 0.25) * step_T
            x_off = step_dx / (b_val - 1.0)
            exp_tau = float(np.exp(omega * tau_step))
            dcm_nom_x = p_zmp_st[0] + x_off * exp_tau
            dcm_nom_y = p_zmp_st[1] + s_sign * y_off_nom * exp_tau
            zmp_ref_x = p_zmp_st[0] + k_dcm * (dcm_x - dcm_nom_x)
            zmp_ref_y = p_zmp_st[1] + k_dcm * (dcm_y - dcm_nom_y)

        # Synchronized pelvis descent across both drops (+140 -> +70 -> 0 mm)
        prog_1 = float(np.clip((p_com[0] - (x_drop1 - 0.14)) / 0.34, 0.0, 1.0))
        prog_2 = float(np.clip((p_com[0] - (x_drop2 - 0.14)) / 0.34, 0.0, 1.0))
        z_target_deck = riser_h * (1.0 - prog_1) + riser_h * (1.0 - prog_2)
        z_ground_smooth += 0.025 * (z_target_deck - z_ground_smooth)
        z_pelvis_ref = z_ground_smooth + z_nom

        fz_des = total_mass * (g + 420.0 * (z_pelvis_ref - p_com[2]) - 42.0 * v_com[2])
        fz_des = float(np.clip(fz_des, 0.35 * total_mass * g, 2.15 * total_mass * g))

        if in_ds:
            zmp_ref_x = float(np.clip(zmp_ref_x, min(p_l_xy[0], p_r_xy[0]) - 0.09, max(p_l_xy[0], p_r_xy[0]) + 0.09))
            zmp_ref_y = float(np.clip(zmp_ref_y, min(p_l_xy[1], p_r_xy[1]) - 0.04, max(p_l_xy[1], p_r_xy[1]) + 0.04))
        else:
            zmp_ref_x = float(np.clip(zmp_ref_x, p_zmp_st[0] - 0.10, p_zmp_st[0] + 0.10))
            zmp_ref_y = float(np.clip(zmp_ref_y, p_zmp_st[1] - 0.035, p_zmp_st[1] + 0.035))

        fx_des = total_mass * (g / z_nom) * (p_com[0] - zmp_ref_x)
        fy_des = total_mass * (g / z_nom) * (p_com[1] - zmp_ref_y)

        w_total = np.array([
            float(np.clip(fx_des, -260.0, 260.0)),
            float(np.clip(fy_des, -220.0, 220.0)),
            fz_des,
            0.0,
            0.0,
            0.0,
        ])

        e_rot = mat_to_rotvec_err(r_pelv_des, pelv_mat)
        tau_pelv = 650.0 * e_rot - 45.0 * pelv_w

        ctrl = np.zeros(model.nu)
        for i in upper_act:
            q_err = q_init[i] - data.qpos[act_qidx[i]]
            dq = data.qvel[act_vidx[i]]
            ctrl[i] = 160.0 * q_err - 14.0 * dq + data.qfrc_bias[act_vidx[i]]

        for side in ("left", "right"):
            is_left = side == "left"
            v_idx = l_leg_v if is_left else r_leg_v
            a_idx = l_leg_act if is_left else r_leg_act
            j_p = (jac_p_l if is_left else jac_p_r)[:, v_idx]
            j_r = (jac_r_l if is_left else jac_r_r)[:, v_idx]
            j_6 = np.vstack([j_p, j_r])
            p_cur = p_l if is_left else p_r
            v_cur = v_l if is_left else v_r
            r_cur = r_l if is_left else r_r
            w_cur = w_l if is_left else w_r
            w_share = w_l_share if is_left else w_r_share

            if w_share > 0.0:
                w_st = w_total * w_share
                w_st[3] = w_share * tau_pelv[0]
                w_st[4] = w_share * tau_pelv[1]
                w_st[5] = w_share * tau_pelv[2]
                e_f = mat_to_rotvec_err(r_flat, r_cur)
                w_st[3:6] -= (180.0 * e_f - 18.0 * w_cur)
                w_st[4] += -w_st[2] * float(np.clip(zmp_ref_x - p_cur[0], -0.09, 0.09))
                w_st[3] += w_st[2] * float(np.clip(zmp_ref_y - p_cur[1], -0.035, 0.035))
                ctrl[a_idx] = data.qfrc_bias[v_idx] - j_6.T @ w_st
            else:
                s = phase_sw
                sw_dur = (1.0 - ds_frac) * step_T
                z_land = descent_stair_height(sw_tgt_x, x_drop1, x_drop2, riser_h)
                sw_x = sw_start_pos[0] + (sw_tgt_x - sw_start_pos[0]) * (3.0 * s ** 2 - 2.0 * s ** 3)
                sw_y = sw_start_pos[1] + (sw_tgt_y - sw_start_pos[1]) * (3.0 * s ** 2 - 2.0 * s ** 3)
                sw_vx = (sw_tgt_x - sw_start_pos[0]) * (6.0 * s * (1.0 - s)) / sw_dur
                sw_vy = (sw_tgt_y - sw_start_pos[1]) * (6.0 * s * (1.0 - s)) / sw_dur

                sw_z, sw_vz = stair_descent_swing_profile(
                    s=s,
                    z_start=float(sw_start_pos[2]),
                    z_land=z_land,
                    swing_clear=swing_clear,
                    sw_dur=sw_dur,
                )

                pos_err = np.array([sw_x, sw_y, sw_z]) - p_cur
                vel_err = np.array([sw_vx, sw_vy, sw_vz]) - v_cur
                f_sw = np.array([2000.0, 2000.0, 3200.0]) * pos_err + np.array([85.0, 85.0, 110.0]) * vel_err
                e_rot_sw = mat_to_rotvec_err(r_flat, r_cur)
                m_sw = 240.0 * e_rot_sw - 18.0 * w_cur
                ctrl[a_idx] = data.qfrc_bias[v_idx] + j_6.T @ np.concatenate([f_sw, m_sw])

        ctrl = np.clip(ctrl, model.actuator_ctrlrange[:, 0], model.actuator_ctrlrange[:, 1])
        data.ctrl[:] = ctrl
        knee_trq_hist.append(float(max(abs(ctrl[l_knee_id]), abs(ctrl[r_knee_id]))))

        qd_act = np.array([data.qvel[v] for v in act_vidx])
        p_pos, p_neg, p_cu, p_reg = compute_electromechanical_step_power(ctrl, qd_act, kt_n_arr, rw_hot_arr)
        p_mech_pos_hist.append(p_pos)
        p_mech_neg_hist.append(p_neg)
        p_regen_bus_hist.append(p_reg)
        e_motor_mech_j += p_pos * dt
        e_neg_mech_j += p_neg * dt
        e_cu_j += p_cu * dt
        e_regen_bus_j += p_reg * dt

        if verbose and step % 150 == 0:
            print(
                f"t={t:4.2f} X={data.qpos[0]:+.3f} Z={data.qpos[2]:.3f} lvl={latched_target_level} "
                f"R={np.rad2deg(roll_pelv):+5.1f} P={np.rad2deg(pitch_pelv):+5.1f} "
                f"L=({p_l[0]:+.3f},{p_l[2]:.3f}) R=({p_r[0]:+.3f},{p_r[2]:.3f}) Regen={p_reg:5.1f}W"
            )
        mujoco.mj_step(model, data)

    # Telemetry Summary
    t_arr = np.array(t_hist)
    x_final = float(x_hist[-1]) if x_hist else 0.0
    z_initial = float(z_hist[0]) if z_hist else 0.0
    z_final = float(z_hist[-1]) if z_hist else 0.0
    lf_z_final = float(lf_z_hist[-1]) if lf_z_hist else 1.0
    rf_z_final = float(rf_z_hist[-1]) if rf_z_hist else 1.0
    roll_arr = np.array(roll_hist)
    pitch_arr = np.array(pitch_hist)
    roll_rms = float(np.sqrt(np.mean(roll_arr ** 2)))
    pitch_rms = float(np.sqrt(np.mean(pitch_arr ** 2)))
    peak_knee_nm = float(np.max(knee_trq_hist)) if knee_trq_hist else 0.0
    peak_l_grf = float(np.max(l_grf_hist)) if l_grf_hist else 0.0
    peak_r_grf = float(np.max(r_grf_hist)) if r_grf_hist else 0.0
    both_feet_floor = bool(
        (not fallen)
        and (lf_z_final <= 0.015)
        and (rf_z_final <= 0.015)
        and (x_final > x_drop2 + 0.35)
    )
    regen_efficiency_pct = float((e_regen_bus_j / max(e_motor_mech_j, 1e-6)) * 100.0)
    peak_regen_w = float(np.max(p_regen_bus_hist)) if p_regen_bus_hist else 0.0
    grav_potential_drop_j = float(total_mass * g * top_elev)

    print(f"Total Simulated Time        : {t_arr[-1]:.2f} s ({len(t_arr)} physics steps)")
    print("Skyhook External Force      : 0.0 N (Strictly Disabled)")
    print(f"Staircase Drop Geometry     : 2 risers (-{riser_h*1000:.0f} mm ea -> -{top_elev*1000:.0f} mm total @ X={x_drop1:.2f}/{x_drop2:.2f} m)")
    print(f"Forward Distance Walked     : {x_final:.3f} m")
    print(f"Pelvis Elevation Delta      : {z_final - z_initial:+.3f} m ({z_initial:.3f} -> {z_final:.3f} m)")
    print(f"Final Sole Height (L / R)   : {lf_z_final*1000:.1f} mm / {rf_z_final*1000:.1f} mm (Floor = 0.0 mm)")
    print(f"Pelvis Attitude RMS (R / P) : {roll_rms:.2f} deg / {pitch_rms:.2f} deg")
    print(f"Peak Foot GRF (L / R)       : {peak_l_grf:.1f} N / {peak_r_grf:.1f} N")
    print(f"Peak Knee Torque            : {peak_knee_nm:.1f} Nm (Class-Gamma Limit 220 Nm)")
    print(f"29-Actuator Energy Audit    : Motoring={e_motor_mech_j:.1f} J | Neg Braking={e_neg_mech_j:.1f} J | Cu Loss={e_cu_j:.1f} J")
    print(f"800V DC Bus Regen Recovered : {e_regen_bus_j:.1f} J (Peak {peak_regen_w:.1f} W, mgh={grav_potential_drop_j:.1f} J, Ratio {regen_efficiency_pct:.1f}%)")
    print(f"Stair Descent Status        : {'PASSED' if both_feet_floor else 'FAILED'}")

    telemetry = {
        "module": "simulate_stair_descent_mujoco.py",
        "mujoco_version": mujoco.__version__,
        "skyhook_force_n": 0.0,
        "duration_s": round(float(t_arr[-1]), 3),
        "num_risers": 2,
        "riser_drop_mm": round(riser_h * 1000.0, 1),
        "total_stair_descent_mm": round(top_elev * 1000.0, 1),
        "drop_x_m": [x_drop1, x_drop2],
        "forward_distance_m": round(x_final, 3),
        "pelvis_z_start_m": round(z_initial, 3),
        "pelvis_z_end_m": round(z_final, 3),
        "pelvis_descent_cm": round((z_final - z_initial) * 100.0, 2),
        "left_foot_final_z_mm": round(lf_z_final * 1000.0, 1),
        "right_foot_final_z_mm": round(rf_z_final * 1000.0, 1),
        "roll_rms_deg": round(roll_rms, 2),
        "pitch_rms_deg": round(pitch_rms, 2),
        "peak_left_grf_n": round(peak_l_grf, 1),
        "peak_right_grf_n": round(peak_r_grf, 1),
        "peak_knee_torque_nm": round(peak_knee_nm, 1),
        "motoring_mech_energy_j": round(e_motor_mech_j, 1),
        "eccentric_braking_energy_j": round(e_neg_mech_j, 1),
        "hot_copper_loss_j": round(e_cu_j, 1),
        "net_dc_bus_regen_energy_j": round(e_regen_bus_j, 1),
        "peak_regen_power_w": round(peak_regen_w, 1),
        "regen_to_motoring_pct": round(regen_efficiency_pct, 1),
        "completed_without_fall": bool(not fallen),
        "both_feet_descended_stairs": both_feet_floor,
    }
    json_path = os.path.join(base_dir, "figure05_stair_descent_telemetry.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(telemetry, f, indent=2)
    print(f"[SAVED] Telemetry JSON -> {json_path}")

    # 4-Panel Engineering Visualization
    plt.style.use("dark_background")
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.patch.set_facecolor("#090d16")

    # Panel 1: Side-view Foot Sole Trajectory Z(X) down 2-Step Staircase
    ax = axes[0, 0]
    ax.set_facecolor("#0f172a")
    gx = np.linspace(-0.20, max(2.2, x_final + 0.15), 600)
    gz_mm = np.array([descent_stair_height(float(xv), x_drop1, x_drop2, riser_h) * 1000.0 for xv in gx])
    ax.fill_between(gx, -15.0, gz_mm, color="#1e293b", alpha=0.95, label="2-Step Descending Staircase (+140 -> +70 -> 0 mm)")
    ax.plot(gx, gz_mm, color="#94a3b8", lw=2.2)
    ax.plot(lf_x_hist, np.array(lf_z_hist) * 1000.0, color="#38bdf8", lw=2.0, label="Left Foot Sole Z(X)")
    ax.plot(rf_x_hist, np.array(rf_z_hist) * 1000.0, color="#f97316", lw=2.0, ls="--", label="Right Foot Sole Z(X)")
    ax.axvline(x_drop1, color="#facc15", ls=":", lw=1.3, label=f"Drops X={x_drop1:.2f} / {x_drop2:.2f} m")
    ax.axvline(x_drop2, color="#facc15", ls=":", lw=1.3)
    ax.set_title("1. 2-Step -140 mm Stair Descent Side-View Trajectory", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Sagittal Position X [m]")
    ax.set_ylabel("Sole Elevation Z [mm]")
    ax.set_ylim(-15, 290)
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    # Panel 2: Pelvis & Soles Descent Z(t)
    ax = axes[0, 1]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, np.array(z_hist) * 100.0, color="#a855f7", lw=2.2, label="Pelvis COM Z [cm]")
    ax.plot(t_arr, np.array(lf_z_hist) * 100.0, color="#38bdf8", lw=1.6, label="Left Foot Z [cm]")
    ax.plot(t_arr, np.array(rf_z_hist) * 100.0, color="#f97316", lw=1.6, label="Right Foot Z [cm]")
    ax.axhline(riser_h * 100.0, color="#34d399", ls=":", lw=1.1, label="Mid Tread (+7.0 cm)")
    ax.axhline(0.0, color="#10b981", ls="--", lw=1.2, label="Lower Floor (0.0 cm)")
    ax.set_title("2. Vertical Descent Profile (-140 mm -> 0 mm)", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Height [cm]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    # Panel 3: Pelvis Roll & Pitch Attitude Stability
    ax = axes[1, 0]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, roll_arr, color="#22d3ee", lw=1.8, label=f"Roll (RMS {roll_rms:.2f} deg)")
    ax.plot(t_arr, pitch_arr, color="#f43f5e", lw=1.8, label=f"Pitch (RMS {pitch_rms:.2f} deg)")
    ax.axhline(0.0, color="#64748b", lw=1.0, ls=":")
    ax.set_title("3. Skyhook-Free Pelvis Attitude Stability", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Orientation [deg]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    # Panel 4: Real 29-Actuator Mechanical Power vs 800V DC Bus Regen Recovery
    ax = axes[1, 1]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, p_mech_pos_hist, color="#f97316", lw=1.3, alpha=0.85, label=f"Positive Motoring ({e_motor_mech_j:.0f} J)")
    ax.plot(t_arr, -np.array(p_mech_neg_hist), color="#38bdf8", lw=1.3, alpha=0.75, label=f"Eccentric Braking ({e_neg_mech_j:.0f} J)")
    ax.fill_between(t_arr, 0.0, -np.array(p_regen_bus_hist), color="#10b981", alpha=0.55, label=f"800V DC Bus Regen ({e_regen_bus_j:.1f} J / {regen_efficiency_pct:.1f}%)")
    ax.axhline(0.0, color="#94a3b8", lw=1.0)
    ax.set_title("4. 29-Actuator Power Flow & 800V Bus Regenerative Braking", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Electrical / Shaft Power [W]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    fig.suptitle(
        f"FIGURE 05 | Skyhook-Free MuJoCo 3.6 2-Step -140 mm Stair Descent & Bus Regen "
        f"(Walked {x_final:.2f} m, Regen = {e_regen_bus_j:.1f} J, Floor = {both_feet_floor})",
        fontsize=14,
        fontweight="bold",
        color="#f8fafc",
    )
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    png_path = os.path.join(base_dir, "figure05_mujoco_stair_descent_benchmark.png")
    plt.savefig(png_path, dpi=220, facecolor=fig.get_facecolor())
    plt.close(fig)
    print(f"[SAVED] Visualization -> {png_path}")

    assert not fallen, "Robot fell during multi-riser stair descent"
    assert both_feet_floor, (
        f"Both feet failed to reach lower floor: L_z={lf_z_final*1000:.1f} mm, R_z={rf_z_final*1000:.1f} mm"
    )
    assert e_regen_bus_j > 50.0, f"Expected substantial regenerative recovery during -140 mm descent, got {e_regen_bus_j:.1f} J"
    assert peak_knee_nm < 220.0, f"Peak knee torque exceeded limit: {peak_knee_nm:.1f} Nm"
    return telemetry


if __name__ == "__main__":
    run_stair_descent_simulation(verbose=False)
