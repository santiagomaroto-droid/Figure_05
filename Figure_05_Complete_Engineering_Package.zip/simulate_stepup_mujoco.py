"""
Figure 05 - Skyhook-Free MuJoCo 3.6 Discrete +75 mm Pallet Curb Step-Up Controller
===============================================================================
Authors: Santiago Maroto (Lead Researcher) & Project Figure 05 Engineering Group
Target: Kyle Edelberg & Brett Adcock, Figure AI

Architecture (100% Pure Rigid-Body Physics, Zero Skyhook Forces):
1. Strict skyhook prohibition: `data.qfrc_applied[:] = 0.0` at every 500 Hz step.
2. Discrete raised industrial pallet/curb deck (`+75 mm`, step rise at X = 0.34 m)
   injected into `figure05_mujoco.xml` without altering ground friction/contact dynamics.
3. Curb-aware Divergent Component of Motion (DCM / Capture Point) deadbeat foothold
   planner with cliff-edge exclusion (`snap_safe_foothold`) so the 26 cm sole never
   straddles the vertical riser (`[x_step - 0.135, x_step + 0.135]`).
4. Early-elevation 6-DOF operational-space swing trajectory clearing the 75 mm vertical
   riser cleanly before transitioning to sustained upper-deck bipedal locomotion.
5. Direct MuJoCo contact-frame reaction force measurement (`mj_contactForce`) across
   both lower floor (`z = 0.0 m`) and upper pallet deck (`z = +0.075 m`).
"""

import json
import os
import mujoco
import numpy as np
import matplotlib.pyplot as plt

from figure05_mujoco_common import (
    build_actuator_mappings,
    mat_to_rotvec_err,
    setup_crouched_biped,
    sum_support_grfs,
)


def terrain_height_at(x: float, x_step: float = 0.34, step_h: float = 0.075) -> float:
    """Return exact rigid support surface height Z [m] at sagittal coordinate X."""
    return step_h if x >= x_step else 0.0


def snap_safe_foothold(
    x_raw: float,
    p_st_x: float,
    x_step: float = 0.34,
    half_foot: float = 0.135,
) -> float:
    """
    Prevent the 26 cm sole from landing straddling the discrete curb edge.

    Any raw DCM foothold falling inside `[x_step - half_foot, x_step + half_foot]`
    is projected either cleanly onto the lower approach floor (`x_step - 0.145`)
    or decisively onto the flat upper deck (`x_step + 0.145`). Once the stance
    foot is already staged near the curb (`p_st_x >= 0.06`), the next step always
    commits forward onto the upper deck so feet never stall behind the riser.
    """
    lo_edge = x_step - half_foot
    hi_edge = x_step + half_foot
    if lo_edge < x_raw < hi_edge:
        if p_st_x < 0.06 and x_raw < x_step - 0.04:
            return x_step - (half_foot + 0.010)
        return x_step + (half_foot + 0.010)
    return x_raw


def swing_elevation_profile(
    s: float,
    z_start: float,
    z_land: float,
    tgt_x: float,
    x_step: float,
    step_h: float,
    swing_clear: float,
    step_T: float,
) -> tuple[float, float]:
    """
    Compute swing-foot vertical target Z [m] and vertical velocity Vz [m/s] over s in [0, 1].

    Uses rapid initial lift (`s / 0.25`) and extra high clearance (`+65 mm` above upper deck)
    when climbing the discrete riser (`z_land >= step_h - 0.01`) so the entire 26 cm sole
    clears `+75 mm` before the toe advances across `x_step`.
    """
    climbing_curb = (step_h > 0.0) and (z_land >= step_h - 0.01) and (z_start < z_land - 0.01)
    effective_clear = swing_clear + (0.045 if climbing_curb else 0.0)
    z_touch = z_land - 0.006  # pre-load sole cleanly onto contact surface before switch
    if climbing_curb:
        climb_u = min(1.0, s / 0.25)
        z_base = z_start + (z_touch - z_start) * (3.0 * climb_u ** 2 - 2.0 * climb_u ** 3)
        if s < 0.25:
            dz_base_dt = (z_touch - z_start) * (6.0 * climb_u * (1.0 - climb_u)) / (0.25 * step_T)
        else:
            dz_base_dt = 0.0
        arc = effective_clear * (np.sin(np.pi * min(1.0, s)) ** 1.1)
        darc_dt = effective_clear * 1.1 * (np.sin(np.pi * max(1e-4, min(0.9999, s))) ** 0.1) * np.cos(np.pi * s) * (np.pi / step_T)
    else:
        z_base = z_start + (z_touch - z_start) * (3.0 * s ** 2 - 2.0 * s ** 3)
        dz_base_dt = (z_touch - z_start) * (6.0 * s * (1.0 - s)) / step_T
        arc = effective_clear * (np.sin(np.pi * s) ** 2)
        darc_dt = effective_clear * (np.pi / step_T) * np.sin(2.0 * np.pi * s)

    return float(z_base + arc), float(dz_base_dt + darc_dt)


def run_stepup_simulation(
    verbose: bool = False,
    step_h: float = 0.075,
    x_step: float = 0.34,
):
    print("=================================================================")
    print("FIGURE 05: SKYHOOK-FREE MUJOCO 3.6 +75 MM CURB STEP-UP BENCHMARK")
    print("=================================================================")

    base_dir = os.path.dirname(os.path.abspath(__file__))
    xml_path = os.path.join(base_dir, "figure05_mujoco.xml")
    with open(xml_path, "r", encoding="utf-8") as f:
        xml_str = f.read()

    deck_half_len = 2.00
    deck_pos_x = x_step + deck_half_len
    deck_pos_z = 0.5 * step_h

    if step_h > 0.0:
        curb_geom_xml = (
            f'\n        <geom name="pallet_curb" type="box" contype="1" conaffinity="1" '
            f'pos="{deck_pos_x:.4f} 0.0 {deck_pos_z:.5f}" '
            f'size="{deck_half_len:.3f} 1.20 {deck_pos_z:.5f}" '
            f'rgba="0.22 0.28 0.38 1.0" friction="1.0 0.005 0.0005"/>\n'
        )
    else:
        curb_geom_xml = ""
    if "</worldbody>" not in xml_str:
        raise RuntimeError("Missing </worldbody> closing tag in figure05_mujoco.xml")
    xml_step = xml_str.replace("</worldbody>", curb_geom_xml + "    </worldbody>", 1)

    model = mujoco.MjModel.from_xml_string(xml_step)
    data = mujoco.MjData(model)

    dt = model.opt.timestep
    g = 9.80665
    total_mass = float(np.sum(model.body_mass))

    setup_crouched_biped(model, data)

    maps = build_actuator_mappings(model)
    act_qidx = maps["act_qidx"]
    act_vidx = maps["act_vidx"]
    idx_map = maps["idx_map"]
    l_leg_v = maps["l_leg_v"]
    r_leg_v = maps["r_leg_v"]
    l_leg_act = maps["l_leg_act"]
    r_leg_act = maps["r_leg_act"]
    upper_act = maps["upper_act"]
    q_init = np.array([data.qpos[idx] for idx in act_qidx])

    l_site = model.site("left_foot_contact").id
    r_site = model.site("right_foot_contact").id
    l_body = model.body("left_ankle").id
    r_body = model.body("right_ankle").id
    floor_geom = model.geom("floor").id
    support_geoms = {floor_geom}
    if step_h > 0.0:
        support_geoms.add(model.geom("pallet_curb").id)

    jac_com = np.zeros((3, model.nv))
    jac_p_l = np.zeros((3, model.nv))
    jac_r_l = np.zeros((3, model.nv))
    jac_p_r = np.zeros((3, model.nv))
    jac_r_r = np.zeros((3, model.nv))

    # Gait & DCM parameters
    step_T = 0.42
    ds_frac = 0.16
    half_y = 0.105
    swing_clear = 0.085
    z_nom = 0.870
    omega = np.sqrt(g / z_nom)
    b_val = np.exp(omega * step_T)
    y_off_nom = (2.0 * half_y) / (b_val + 1.0)
    k_dcm = 1.45

    duration_s = 6.0
    n_steps = int(duration_s / dt)
    settle_steps = 140  # 0.28 s stand + pre-shift weight onto right stance foot

    swing_side = "left"
    sw_start_pos = data.site_xpos[l_site].copy()
    v_x_target = 0.40
    step_dx_nom = v_x_target * step_T
    sw_tgt_x = sw_start_pos[0] + 0.5 * step_dx_nom
    sw_tgt_y = half_y
    step_climb_mode = False
    z_ground_smooth = 0.0

    # Telemetry logs
    t_hist, x_hist, y_hist, z_hist = [], [], [], []
    roll_hist, pitch_hist = [], []
    lf_x_hist, rf_x_hist = [], []
    lf_z_hist, rf_z_hist = [], []
    l_grf_hist, r_grf_hist = [], []
    knee_trq_hist = []

    fallen = False
    l_knee_id = idx_map["act_left_knee"]
    r_knee_id = idx_map["act_right_knee"]

    for step in range(n_steps):
        t = step * dt
        mujoco.mj_forward(model, data)

        # CRITICAL: ZERO SKYHOOK FORCES
        data.qfrc_applied[:] = 0.0

        p_l = data.site_xpos[l_site].copy()
        p_r = data.site_xpos[r_site].copy()
        r_l = data.site_xmat[l_site].reshape(3, 3)
        r_r = data.site_xmat[r_site].reshape(3, 3)

        mujoco.mj_jacSubtreeCom(model, data, jac_com, model.body("pelvis").id)
        p_com = data.subtree_com[model.body("pelvis").id].copy()
        v_com = jac_com @ data.qvel

        mujoco.mj_jacSite(model, data, jac_p_l, jac_r_l, l_site)
        mujoco.mj_jacSite(model, data, jac_p_r, jac_r_r, r_site)
        v_l = jac_p_l @ data.qvel
        w_l = jac_r_l @ data.qvel
        v_r = jac_p_r @ data.qvel
        w_r = jac_r_r @ data.qvel

        pelv_mat = data.body("pelvis").xmat.reshape(3, 3)
        pelv_w = data.qvel[3:6].copy()
        roll_pelv = np.arctan2(pelv_mat[2, 1], pelv_mat[2, 2])
        pitch_pelv = -np.arcsin(np.clip(pelv_mat[2, 0], -1.0, 1.0))

        # Measure foot reaction forces against BOTH floor & pallet_curb
        l_grf, r_grf = sum_support_grfs(model, data, support_geoms, l_body, r_body)

        # Log telemetry
        t_hist.append(t)
        x_hist.append(float(data.qpos[0]))
        y_hist.append(float(data.qpos[1]))
        z_hist.append(float(data.qpos[2]))
        roll_hist.append(float(np.rad2deg(roll_pelv)))
        pitch_hist.append(float(np.rad2deg(pitch_pelv)))
        lf_x_hist.append(float(p_l[0]))
        rf_x_hist.append(float(p_r[0]))
        lf_z_hist.append(float(p_l[2]))
        rf_z_hist.append(float(p_r[2]))
        l_grf_hist.append(float(l_grf))
        r_grf_hist.append(float(r_grf))

        local_ground = min(p_l[2], p_r[2])
        if data.qpos[2] - local_ground < 0.45:
            fallen = True
            print(f"[ABORT] Fall detected at t={t:.2f}s Z_pel={data.qpos[2]:.3f}m")
            break

        # Phase state machine
        tau_step = 0.0
        step_num = 0
        if step < settle_steps:
            in_ds = True
            phase_sw = 0.0
            s_sign = 1.0 if swing_side == "left" else -1.0
            step_climb_mode = False
            z_ground = max(p_l[2], p_r[2])
            if step == settle_steps - 1:
                sw_start_pos = p_l.copy()
                sw_tgt_x = snap_safe_foothold(p_r[0] + 0.15, p_r[0], x_step)
                sw_tgt_y = p_r[1] + 2.0 * half_y
        else:
            step_idx = step - settle_steps
            ticks_per_step = int(step_T / dt)
            step_num = step_idx // ticks_per_step
            tau_step = (step_idx % ticks_per_step) * dt
            if step_idx % ticks_per_step == 0 and step_idx > 0:
                swing_side = "right" if swing_side == "left" else "left"
                sw_start_pos = p_l.copy() if swing_side == "left" else p_r.copy()

            s_sign = 1.0 if swing_side == "left" else -1.0
            in_ds = tau_step < (ds_frac * step_T)
            p_st = p_r if swing_side == "left" else p_l
            z_ground = max(terrain_height_at(p_st[0], x_step, step_h), 0.0)

            v_des = v_x_target if step_num >= 1 else 0.25
            step_dx = v_des * step_T
            x_off = step_dx / (b_val - 1.0)
            dcm_x = p_com[0] + v_com[0] / omega
            dcm_y = p_com[1] + v_com[1] / omega

            if in_ds:
                phase_sw = 0.0
                if swing_side == "left":
                    sw_start_pos = p_l.copy()
                else:
                    sw_start_pos = p_r.copy()
                # Decide & latch step-up vs pre-curb plateau during double-support only
                x_end_pred = p_st[0] + (dcm_x - p_st[0]) * np.exp(omega * (1.0 - ds_frac) * step_T) - x_off
                step_climb_mode = bool(
                    (step_h > 0.0) and (
                        (x_end_pred >= x_step - 0.03)
                        or (sw_start_pos[2] >= step_h - 0.02)
                        or (p_st[0] >= x_step - 0.02)
                    )
                )
            else:
                phase_sw = min(1.0, (tau_step - ds_frac * step_T) / ((1.0 - ds_frac) * step_T))

            if phase_sw < 0.85:
                tgt_x_raw = dcm_x - x_off
                if step_h > 0.0 and step_climb_mode:
                    x_min = max(x_step + 0.085, p_st[0] - 0.08)
                    x_max = max(x_min + 0.04, p_st[0] + 0.32)
                    sw_tgt_x = float(np.clip(tgt_x_raw, x_min, x_max))
                elif step_h > 0.0:
                    x_min = p_st[0] - 0.08
                    x_max = max(x_min + 0.02, x_step - 0.135)
                    sw_tgt_x = float(np.clip(tgt_x_raw, x_min, x_max))
                else:
                    sw_tgt_x = float(np.clip(tgt_x_raw, p_st[0] - 0.08, p_st[0] + 0.36))

                tgt_y_raw = dcm_y + s_sign * y_off_nom - 0.15 * p_com[1]
                y_a = p_st[1] + s_sign * 0.14
                y_b = p_st[1] + s_sign * 0.29
                sw_tgt_y = float(np.clip(tgt_y_raw, min(y_a, y_b), max(y_a, y_b)))

        # Centroidal Wrench Reference relative to active support deck height
        p_l_xy = p_l[:2]
        p_r_xy = p_r[:2]
        if in_ds:
            w_l_share, w_r_share = 0.5, 0.5
            p_zmp_st = 0.5 * (p_l + p_r)
        elif swing_side == "left":
            w_l_share, w_r_share = 0.0, 1.0
            p_zmp_st = p_r.copy()
        else:
            w_l_share, w_r_share = 1.0, 0.0
            p_zmp_st = p_l.copy()

        dcm_x = p_com[0] + v_com[0] / omega
        dcm_y = p_com[1] + v_com[1] / omega

        if step < settle_steps:
            # Pre-shift COM gently toward right stance foot before lifting left foot
            zmp_ref_x = p_zmp_st[0] - 0.015
            zmp_ref_y = 0.045 if dcm_y > -0.055 else -0.02
        elif in_ds:
            zmp_ref_x = p_zmp_st[0] - 0.01
            zmp_ref_y = p_zmp_st[1]
        else:
            step_dx = (v_x_target if step_num >= 1 else 0.25) * step_T
            x_off = step_dx / (b_val - 1.0)
            exp_tau = float(np.exp(omega * tau_step))
            dcm_nom_x = p_zmp_st[0] + x_off * exp_tau
            dcm_nom_y = p_zmp_st[1] + s_sign * y_off_nom * exp_tau
            zmp_ref_x = p_zmp_st[0] + k_dcm * (dcm_x - dcm_nom_x)
            zmp_ref_y = p_zmp_st[1] + k_dcm * (dcm_y - dcm_nom_y)

        # Smooth pelvis height reference as COM climbs across the +75 mm curb edge
        if step_h > 0.0:
            climb_prog = float(np.clip((p_com[0] - (x_step - 0.08)) / 0.28, 0.0, 1.0))
            z_target_deck = step_h * climb_prog
        else:
            z_target_deck = 0.0
        z_ground_smooth += 0.015 * (z_target_deck - z_ground_smooth)
        z_pelvis_ref = z_ground_smooth + z_nom

        fz_des = total_mass * (g + 420.0 * (z_pelvis_ref - p_com[2]) - 42.0 * v_com[2])
        fz_des = float(np.clip(fz_des, 0.35 * total_mass * g, 2.15 * total_mass * g))

        if in_ds:
            zmp_ref_x = float(np.clip(zmp_ref_x, min(p_l_xy[0], p_r_xy[0]) - 0.09, max(p_l_xy[0], p_r_xy[0]) + 0.09))
            zmp_ref_y = float(np.clip(zmp_ref_y, min(p_l_xy[1], p_r_xy[1]) - 0.04, max(p_l_xy[1], p_r_xy[1]) + 0.04))
        else:
            zmp_ref_x = float(np.clip(zmp_ref_x, p_zmp_st[0] - 0.10, p_zmp_st[0] + 0.10))
            zmp_ref_y = float(np.clip(zmp_ref_y, p_zmp_st[1] - 0.035, p_zmp_st[1] + 0.035))

        fx_des = total_mass * (g / z_nom) * (p_com[0] - zmp_ref_x)
        fy_des = total_mass * (g / z_nom) * (p_com[1] - zmp_ref_y)

        w_total = np.array([
            float(np.clip(fx_des, -260.0, 260.0)),
            float(np.clip(fy_des, -220.0, 220.0)),
            fz_des,
            0.0,
            0.0,
            0.0,
        ])

        r_pelv_des = np.array([
            [np.cos(0.045), 0.0, np.sin(0.045)],
            [0.0, 1.0, 0.0],
            [-np.sin(0.045), 0.0, np.cos(0.045)],
        ])
        e_rot = mat_to_rotvec_err(r_pelv_des, pelv_mat)
        tau_pelv = 650.0 * e_rot - 45.0 * pelv_w

        # Whole-body torque distribution
        ctrl = np.zeros(model.nu)
        r_flat = np.eye(3)

        # Upper body spring-damper posture hold (torso, neck, and arms)
        for i in upper_act:
            q_err = q_init[i] - data.qpos[act_qidx[i]]
            dq = data.qvel[act_vidx[i]]
            ctrl[i] = 160.0 * q_err - 14.0 * dq + data.qfrc_bias[act_vidx[i]]

        for side in ["left", "right"]:
            is_left = side == "left"
            v_idx = l_leg_v if is_left else r_leg_v
            a_idx = l_leg_act if is_left else r_leg_act
            j_p = (jac_p_l if is_left else jac_p_r)[:, v_idx]
            j_r = (jac_r_l if is_left else jac_r_r)[:, v_idx]
            j_6 = np.vstack([j_p, j_r])
            p_cur = p_l if is_left else p_r
            v_cur = v_l if is_left else v_r
            r_cur = r_l if is_left else r_r
            w_cur = w_l if is_left else w_r
            w_share = w_l_share if is_left else w_r_share

            if w_share > 0.0:
                w_st = w_total * w_share
                p_ref_st = p_cur
                w_st[3] = w_share * tau_pelv[0]
                w_st[4] = w_share * tau_pelv[1]
                w_st[5] = w_share * tau_pelv[2]
                # Direct foot sole attitude regulation under stance leg
                e_f = mat_to_rotvec_err(r_flat, r_cur)
                w_st[3:6] -= (180.0 * e_f - 18.0 * w_cur)
                # Reaction moment at ankle from ZMP shift inside sole polygon
                w_st[4] += -w_st[2] * float(np.clip(zmp_ref_x - p_ref_st[0], -0.09, 0.09))
                w_st[3] += w_st[2] * float(np.clip(zmp_ref_y - p_ref_st[1], -0.035, 0.035))

                tau_st = data.qfrc_bias[v_idx] - j_6.T @ w_st
                ctrl[a_idx] = tau_st
            else:
                s = phase_sw
                sw_dur = (1.0 - ds_frac) * step_T
                z_land = terrain_height_at(sw_tgt_x, x_step, step_h)
                climbing_up = (step_h > 0.0) and (z_land >= step_h - 0.01) and (sw_start_pos[2] < z_land - 0.01)
                if climbing_up:
                    # Lift vertically first over [0..0.22], glide cleanly above deck over [0.22..0.88]
                    u_x = float(np.clip((s - 0.22) / 0.66, 0.0, 1.0))
                    hx = 3.0 * u_x ** 2 - 2.0 * u_x ** 3
                    dhx_dt = (6.0 * u_x * (1.0 - u_x)) / (0.66 * sw_dur) if 0.0 < u_x < 1.0 else 0.0
                else:
                    hx = 3.0 * s ** 2 - 2.0 * s ** 3
                    dhx_dt = (6.0 * s * (1.0 - s)) / sw_dur

                sw_x = sw_start_pos[0] + (sw_tgt_x - sw_start_pos[0]) * hx
                sw_y = sw_start_pos[1] + (sw_tgt_y - sw_start_pos[1]) * (3.0 * s ** 2 - 2.0 * s ** 3)
                sw_vx = (sw_tgt_x - sw_start_pos[0]) * dhx_dt
                sw_vy = (sw_tgt_y - sw_start_pos[1]) * (6.0 * s * (1.0 - s)) / sw_dur

                sw_z, sw_vz = swing_elevation_profile(
                    s=s,
                    z_start=float(sw_start_pos[2]),
                    z_land=z_land,
                    tgt_x=sw_tgt_x,
                    x_step=x_step,
                    step_h=step_h,
                    swing_clear=swing_clear,
                    step_T=sw_dur,
                )

                pos_err = np.array([sw_x, sw_y, sw_z]) - p_cur
                vel_err = np.array([sw_vx, sw_vy, sw_vz]) - v_cur
                f_sw = np.array([2000.0, 2000.0, 3200.0]) * pos_err + np.array([85.0, 85.0, 110.0]) * vel_err

                e_rot_sw = mat_to_rotvec_err(r_flat, r_cur)
                m_sw = 240.0 * e_rot_sw - 18.0 * w_cur
                w_sw = np.concatenate([f_sw, m_sw])

                tau_sw = data.qfrc_bias[v_idx] + j_6.T @ w_sw
                ctrl[a_idx] = tau_sw

        ctrl = np.clip(ctrl, model.actuator_ctrlrange[:, 0], model.actuator_ctrlrange[:, 1])
        data.ctrl[:] = ctrl
        knee_trq_hist.append(float(max(abs(ctrl[l_knee_id]), abs(ctrl[r_knee_id]))))
        if verbose and step % 100 == 0:
            print(
                f"t={t:4.2f} X={data.qpos[0]:+.3f} Y={data.qpos[1]:+.3f} Z={data.qpos[2]:.3f} "
                f"R={np.rad2deg(roll_pelv):+5.1f} P={np.rad2deg(pitch_pelv):+5.1f} "
                f"sw={swing_side[0]} tgtX={sw_tgt_x:+.3f} L=({p_l[0]:+.3f},{p_l[2]:.3f}) R=({p_r[0]:+.3f},{p_r[2]:.3f})"
            )
        mujoco.mj_step(model, data)

    # Telemetry Summary
    t_arr = np.array(t_hist)
    x_final = float(x_hist[-1]) if x_hist else 0.0
    z_final = float(z_hist[-1]) if z_hist else 0.0
    z_initial = float(z_hist[0]) if z_hist else 0.0
    lf_z_final = float(lf_z_hist[-1]) if lf_z_hist else 0.0
    rf_z_final = float(rf_z_hist[-1]) if rf_z_hist else 0.0
    roll_arr = np.array(roll_hist)
    pitch_arr = np.array(pitch_hist)
    roll_rms = float(np.sqrt(np.mean(roll_arr ** 2)))
    pitch_rms = float(np.sqrt(np.mean(pitch_arr ** 2)))
    peak_knee_nm = float(np.max(knee_trq_hist)) if knee_trq_hist else 0.0
    peak_l_grf = float(np.max(l_grf_hist)) if l_grf_hist else 0.0
    peak_r_grf = float(np.max(r_grf_hist)) if r_grf_hist else 0.0
    both_feet_on_deck = bool((not fallen) and (lf_z_final >= step_h - 0.015) and (rf_z_final >= step_h - 0.015) and (x_final > 1.0))

    print(f"Total Simulated Time        : {t_arr[-1]:.2f} s ({len(t_arr)} physics steps)")
    print(f"Skyhook External Force      : 0.0 N (Strictly Disabled)")
    print(f"Curb Geometry               : +75.0 mm vertical pallet curb at X = {x_step:.2f} m")
    print(f"Forward Distance Walked     : {x_final:.3f} m")
    print(f"Pelvis Elevation Gain       : {z_final - z_initial:+.3f} m ({z_initial:.3f} -> {z_final:.3f} m)")
    print(f"Final Sole Height (L / R)   : {lf_z_final*1000:.1f} mm / {rf_z_final*1000:.1f} mm (Deck = 75.0 mm)")
    print(f"Pelvis Attitude RMS (R / P) : {roll_rms:.2f} deg / {pitch_rms:.2f} deg")
    print(f"Peak Foot GRF (L / R)       : {peak_l_grf:.1f} N / {peak_r_grf:.1f} N")
    print(f"Peak Knee Torque            : {peak_knee_nm:.1f} Nm (Class-Gamma Limit 220 Nm)")
    print(f"Upper Deck Ascension Status : {'PASSED' if both_feet_on_deck else 'FAILED'}")

    telemetry = {
        "module": "simulate_stepup_mujoco.py",
        "mujoco_version": mujoco.__version__,
        "skyhook_force_n": 0.0,
        "duration_s": round(float(t_arr[-1]), 3),
        "step_x_m": x_step,
        "step_height_mm": round(step_h * 1000.0, 1),
        "forward_distance_m": round(x_final, 3),
        "pelvis_z_start_m": round(z_initial, 3),
        "pelvis_z_end_m": round(z_final, 3),
        "pelvis_climb_cm": round((z_final - z_initial) * 100.0, 2),
        "left_foot_final_z_mm": round(lf_z_final * 1000.0, 1),
        "right_foot_final_z_mm": round(rf_z_final * 1000.0, 1),
        "roll_rms_deg": round(roll_rms, 2),
        "pitch_rms_deg": round(pitch_rms, 2),
        "peak_left_grf_n": round(peak_l_grf, 1),
        "peak_right_grf_n": round(peak_r_grf, 1),
        "peak_knee_torque_nm": round(peak_knee_nm, 1),
        "completed_without_fall": bool(not fallen),
        "both_feet_mounted_upper_deck": both_feet_on_deck,
    }
    json_path = os.path.join(base_dir, "figure05_stepup_telemetry.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(telemetry, f, indent=2)
    print(f"[SAVED] Telemetry JSON -> {json_path}")

    # 4-Panel Engineering Visualization
    plt.style.use("dark_background")
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.patch.set_facecolor("#090d16")

    # Panel 1: Side-view Foot Sole Trajectory Z(X) over +75 mm Discrete Curb
    ax = axes[0, 0]
    ax.set_facecolor("#0f172a")
    gx = np.linspace(-0.20, max(1.9, x_final + 0.15), 500)
    gz_mm = np.where(gx >= x_step, step_h * 1000.0, 0.0)
    ax.fill_between(gx, -15.0, gz_mm, color="#1e293b", alpha=0.95, label="Lower Floor + +75 mm Pallet Deck")
    ax.plot(gx, gz_mm, color="#94a3b8", lw=2.2)
    ax.plot(lf_x_hist, np.array(lf_z_hist) * 1000.0, color="#38bdf8", lw=2.0, label="Left Foot Sole Z(X)")
    ax.plot(rf_x_hist, np.array(rf_z_hist) * 1000.0, color="#f97316", lw=2.0, ls="--", label="Right Foot Sole Z(X)")
    ax.axvline(x_step, color="#facc15", ls=":", lw=1.4, label=f"Curb Edge X = {x_step:.2f} m")
    ax.set_title("1. Discrete +75 mm Pallet Curb Side-View Trajectory", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Sagittal Position X [m]")
    ax.set_ylabel("Sole Elevation Z [mm]")
    ax.set_ylim(-15, 225)
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    # Panel 2: Pelvis Climb & Foot Step Z(t)
    ax = axes[0, 1]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, np.array(z_hist) * 100.0, color="#a855f7", lw=2.2, label="Pelvis COM Z [cm]")
    ax.plot(t_arr, np.array(lf_z_hist) * 100.0, color="#38bdf8", lw=1.6, label="Left Foot Z [cm]")
    ax.plot(t_arr, np.array(rf_z_hist) * 100.0, color="#f97316", lw=1.6, label="Right Foot Z [cm]")
    ax.axhline(step_h * 100.0, color="#10b981", ls="--", lw=1.2, label="Upper Deck (+7.5 cm)")
    ax.set_title("2. Vertical Ascension Profile (Z vs Time)", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Height [cm]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="center right")

    # Panel 3: Pelvis Roll & Pitch Attitude Stability
    ax = axes[1, 0]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, roll_arr, color="#22d3ee", lw=1.8, label=f"Roll (RMS {roll_rms:.2f} deg)")
    ax.plot(t_arr, pitch_arr, color="#f43f5e", lw=1.8, label=f"Pitch (RMS {pitch_rms:.2f} deg)")
    ax.axhline(0.0, color="#64748b", lw=1.0, ls=":")
    ax.set_title("3. Skyhook-Free Pelvis Attitude Stability", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Orientation [deg]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="lower left")

    # Panel 4: Alternating Foot Contact GRFs (Floor + Deck)
    ax = axes[1, 1]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, l_grf_hist, color="#38bdf8", lw=1.6, alpha=0.9, label=f"Left GRF (Peak {peak_l_grf:.0f} N)")
    ax.plot(t_arr, r_grf_hist, color="#f97316", lw=1.6, alpha=0.9, label=f"Right GRF (Peak {peak_r_grf:.0f} N)")
    ax.axhline(total_mass * g, color="#10b981", ls="--", lw=1.2, label=f"Robot Weight ({total_mass*g:.0f} N)")
    ax.set_title("4. True MuJoCo Ground & Curb Contact GRF", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Vertical GRF [N]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    fig.suptitle(
        f"FIGURE 05 | Skyhook-Free MuJoCo 3.6 Discrete +75 mm Curb Step-Up "
        f"(Walked {x_final:.2f} m, Both Feet on Deck = {both_feet_on_deck})",
        fontsize=14,
        fontweight="bold",
        color="#ffffff",
    )
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_png = os.path.join(base_dir, "figure05_mujoco_stepup_benchmark.png")
    plt.savefig(out_png, dpi=180, facecolor=fig.get_facecolor())
    plt.close()
    print(f"[SAVED] Benchmark Plot -> {out_png}")
    if step_h > 0.0 and not both_feet_on_deck:
        raise AssertionError(f"Step-up ascension check failed (X={x_final:.2f}m, fallen={fallen})")


if __name__ == "__main__":
    run_stepup_simulation()
