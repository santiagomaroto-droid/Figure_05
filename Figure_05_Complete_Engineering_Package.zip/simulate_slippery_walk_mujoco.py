"""
Project Figure 05 — Module #24: Skyhook-Free MuJoCo 3.6 Oil-Patch Slip Recovery
=============================================================================
Demonstrates true full-body dynamic bipedal walking across a zero-height-step
low-friction oil spill (X in [0.55, 1.55] m, mu = 0.18) flanked by dry factory
concrete (mu = 1.20), with ZERO external skyhook forces (qfrc_applied = 0.0).

Includes an honest A/B comparison on identical MuJoCo physics:
  1. Baseline WBC (no slip observer / unconstricted traction): hits mu = 0.18 at
     full stride velocity (~0.64 m/s), exceeds the Coulomb cone, skids & falls.
  2. Causal Adaptive Friction-Cone WBC (zero-oracle!): detects stance-sole
     micro-slip online using sole-site kinematics + GRF ratio alone, collapses
     its internal mu_hat estimate, clamps planar GRF within 0.80 * mu_hat * fz,
     moderates stride speed on slick surfaces, clears X > 1.55 m onto dry floor,
     and cautiously recovers traction once non-slip stance returns.
"""

from __future__ import annotations

import json
import os
import sys
import numpy as np
import mujoco
import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(__file__))
from figure05_mujoco_common import (
    build_actuator_mappings,
    clamp_and_apply_ctrl,
    mat_to_rotvec_err,
    measure_foot_world_grfs,
    quat_to_roll_pitch_yaw,
    setup_crouched_biped,
    sum_support_grfs,
)

OIL_PATCH_START_X = 0.55
OIL_PATCH_END_X = 1.55
MU_DRY = 1.20
MU_OIL = 0.18


def terrain_friction_at(
    x: float,
    patch_start: float = OIL_PATCH_START_X,
    patch_end: float = OIL_PATCH_END_X,
    mu_dry: float = MU_DRY,
    mu_oil: float = MU_OIL,
) -> float:
    """Ground-truth spatial surface friction map (logging/evaluation ONLY)."""
    return float(mu_oil if patch_start <= x <= patch_end else mu_dry)


def causal_friction_cone_clamp(
    f_xy: np.ndarray,
    fz: float,
    mu_hat: float,
    safety_factor: float = 0.86,
    min_mu: float = 0.08,
) -> np.ndarray:
    """Radially project desired horizontal GRF inside estimated Coulomb cone."""
    fx, fy = float(f_xy[0]), float(f_xy[1])
    if fz <= 0.0:
        return np.zeros(2, dtype=float)
    mu_eff = max(float(mu_hat), min_mu)
    f_max = safety_factor * mu_eff * float(fz)
    mag = float(np.hypot(fx, fy))
    if mag > f_max and mag > 1e-9:
        scale = f_max / mag
        return np.array([fx * scale, fy * scale], dtype=float)
    return np.array([fx, fy], dtype=float)


def update_stance_slip_observer(
    mu_hat: float,
    v_slip_mps: float,
    f_tangential_n: float,
    fz_n: float,
    dt: float,
    v_slip_thresh: float = 0.045,
    mu_min: float = 0.16,
    mu_dry_cap: float = 1.00,
) -> float:
    """
    Strictly causal blind stance-slip observer (zero position / geometry oracle).
    Drops mu_hat rapidly on loaded sole slip and slowly recovers on sustained
    zero-slip loaded traction.
    """
    if fz_n < 220.0 or dt <= 0.0:
        return float(np.clip(mu_hat, mu_min, mu_dry_cap))

    mu_util = float(f_tangential_n / max(fz_n, 1.0))

    if v_slip_mps > v_slip_thresh:
        # Rapid kinetic Coulomb collapse under active loaded sole sliding
        slip_cap = 0.175 if v_slip_mps > 0.055 else 0.22
        mu_obs = float(np.clip(min(max(mu_util, 0.16), slip_cap), mu_min, mu_dry_cap))
        alpha_drop = 1.0 - float(np.exp(-dt / 0.008))
        mu_target = min(mu_hat, mu_obs)
        return float(np.clip((1.0 - alpha_drop) * mu_hat + alpha_drop * mu_target, mu_min, mu_dry_cap))

    if v_slip_mps < 0.015 and fz_n > 280.0 and mu_util > 0.030:
        # Very conservative leaky recovery during sustained non-slip loaded stance
        mu_rec_tgt = float(np.clip(max(mu_hat, min(0.92, 0.45 + 2.4 * mu_util)), mu_min, mu_dry_cap))
        alpha_rec = 1.0 - float(np.exp(-dt / 2.20))
        return float(np.clip((1.0 - alpha_rec) * mu_hat + alpha_rec * mu_rec_tgt, mu_min, mu_dry_cap))

    return float(np.clip(mu_hat, mu_min, mu_dry_cap))


def build_oil_patch_mjcf(base_dir: str) -> str:
    """Split flush floor at Z=0 into dry entry, mu=0.18 oil zone, dry exit."""
    xml_path = os.path.join(base_dir, "figure05_mujoco.xml")
    with open(xml_path, "r", encoding="utf-8") as f:
        xml_txt = f.read()

    old_floor = (
        '<geom name="floor" type="plane" size="10 10 0.1" contype="1" '
        'conaffinity="1" friction="1.2 0.01 0.001" material="mat_grid"/>'
    )
    if old_floor not in xml_txt:
        raise RuntimeError("Could not locate base floor geom in figure05_mujoco.xml")

    patch_geoms = (
        '<geom name="floor_entry" type="box" pos="-9.725 0 -0.05" size="10.275 10 0.05" '
        'contype="1" conaffinity="1" friction="1.2 0.01 0.001" material="mat_grid"/>\n'
        '    <geom name="oil_patch" type="box" pos="1.05 0 -0.05" size="0.50 10 0.05" '
        'contype="1" conaffinity="1" priority="1" condim="4" '
        'friction="0.18 0.003 0.0003" rgba="0.88 0.68 0.12 0.78"/>\n'
        '    <geom name="floor_exit" type="box" pos="10.775 0 -0.05" size="9.225 10 0.05" '
        'contype="1" conaffinity="1" friction="1.2 0.01 0.001" material="mat_grid"/>'
    )
    return xml_txt.replace(old_floor, patch_geoms, 1)


def run_trial(adaptive_cone: bool, max_sim_s: float = 10.0) -> dict:
    """Run one zero-skyhook MuJoCo walk across X in [0.55, 1.55] m oil patch."""
    base_dir = os.path.dirname(__file__)
    xml_str = build_oil_patch_mjcf(base_dir)
    model = mujoco.MjModel.from_xml_string(xml_str)
    data = mujoco.MjData(model)

    setup_crouched_biped(model, data)
    total_mass = float(np.sum(model.body_mass))
    maps = build_actuator_mappings(model)
    act_names = maps["act_names"]
    act_qidx = maps["act_qidx"]
    act_vidx = maps["act_vidx"]
    idx_map = maps["idx_map"]
    l_leg_v = maps["l_leg_v"]
    r_leg_v = maps["r_leg_v"]
    l_leg_act = maps["l_leg_act"]
    r_leg_act = maps["r_leg_act"]
    upper_act = maps["upper_act"]
    q_init = np.array([data.qpos[idx] for idx in act_qidx], dtype=float)

    l_body = model.body("left_ankle").id
    r_body = model.body("right_ankle").id
    l_site = model.site("left_foot_contact").id
    r_site = model.site("right_foot_contact").id
    support_geoms = {
        model.geom("floor_entry").id,
        model.geom("oil_patch").id,
        model.geom("floor_exit").id,
    }

    dt = float(model.opt.timestep)
    g = 9.81
    z_c = 0.870
    omega = float(np.sqrt(g / z_c))

    # Nominal brisk factory gait (demands ~0.25+ mu push-off unless mitigated on oil)
    step_T = 0.40
    ds_frac = 0.16
    by_nom = 0.095
    h_lift = 0.062
    vx_nom = 0.64

    jac_lp = np.zeros((3, model.nv))
    jac_lr = np.zeros((3, model.nv))
    jac_rp = np.zeros((3, model.nv))
    jac_rr = np.zeros((3, model.nv))
    jac_ls = np.zeros((3, model.nv))
    jac_rs = np.zeros((3, model.nv))
    jac_com = np.zeros((3, model.nv))

    # Initial quiet crouch settle (~0.28 s)
    for _ in range(140):
        data.qfrc_applied[:] = 0.0
        for i in range(model.nu):
            qv = data.qpos[act_qidx[i]]
            qdv = data.qvel[act_vidx[i]]
            data.ctrl[i] = 280.0 * (q_init[i] - qv) - 18.0 * qdv
        mujoco.mj_step(model, data)

    p0_l = data.site_xpos[l_site].copy()
    p0_r = data.site_xpos[r_site].copy()
    c0_xy = 0.5 * (p0_l[:2] + p0_r[:2])

    mu_hat = 1.00
    mu_min_observed = 1.00
    v_slip_lpf = 0.0
    slip_consec = 0
    non_slip_clean_s = 0.0
    slip_conf_s = 0.0
    step_prev = -1
    stance_side = 1
    swing = None
    s_sw = 0.0
    sw_start_pos = data.site_xpos[r_site].copy()
    prev_pdes = sw_start_pos.copy()
    swing_first_tick = True

    t_stand = 0.50
    max_sim_s = float(max_sim_s)
    total_steps = int(max_sim_s / dt)

    times = []
    com_x_log = []
    pelvis_z_log = []
    roll_log = []
    pitch_log = []
    mu_hat_log = []
    mu_true_log = []
    slip_spd_log = []
    grf_ratio_log = []
    fz_log = []
    knee_tau_log = []
    skyhook_max = 0.0

    settled_x = float(data.subtree_com[0][0])
    fell = False
    fall_time = None
    max_slip_speed = 0.0
    oil_slip_events = 0
    cleared_oil_exit = False

    for step in range(total_steps):
        t = step * dt
        data.qfrc_applied[:] = 0.0
        skyhook_max = max(skyhook_max, float(np.max(np.abs(data.qfrc_applied))))

        mujoco.mj_jacSubtreeCom(model, data, jac_com, 0)
        com = data.subtree_com[0].copy()
        com_vel = jac_com @ data.qvel

        p_l = data.site_xpos[l_site].copy()
        p_r = data.site_xpos[r_site].copy()
        r_l = data.xmat[l_body].reshape(3, 3).copy()
        r_r = data.xmat[r_body].reshape(3, 3).copy()
        mujoco.mj_jacSite(model, data, jac_lp, jac_lr, l_site)
        mujoco.mj_jacSite(model, data, jac_rp, jac_rr, r_site)

        v_l = jac_lp @ data.qvel
        v_r = jac_rp @ data.qvel
        v_ls_xy = v_l[:2]
        v_rs_xy = v_r[:2]

        roll, pitch, yaw = quat_to_roll_pitch_yaw(data.qpos[3:7])
        ang_vel = data.qvel[3:6]
        droll, dpitch, dyaw = float(ang_vel[0]), float(ang_vel[1]), float(ang_vel[2])

        l_fz_s, r_fz_s = sum_support_grfs(model, data, support_geoms, l_body, r_body)
        grf_l, grf_r = measure_foot_world_grfs(model, data, support_geoms, l_body, r_body)
        fz_total_meas = float(l_fz_s + r_fz_s)

        # Active stance sole slip speed & GRF ratio
        if t < t_stand:
            st_v_slip = float(0.5 * (np.hypot(*v_ls_xy) + np.hypot(*v_rs_xy)))
            st_ft = float(np.hypot(grf_l[0] + grf_r[0], grf_l[1] + grf_r[1]))
            st_fz = fz_total_meas
            st_x = float(0.5 * (data.site_xpos[l_site][0] + data.site_xpos[r_site][0]))
        elif stance_side == 1:
            st_v_slip = float(np.hypot(*v_ls_xy))
            st_ft = float(np.hypot(grf_l[0], grf_l[1]))
            st_fz = float(grf_l[2])
            st_x = float(data.site_xpos[l_site][0])
        else:
            st_v_slip = float(np.hypot(*v_rs_xy))
            st_ft = float(np.hypot(grf_r[0], grf_r[1]))
            st_fz = float(grf_r[2])
            st_x = float(data.site_xpos[r_site][0])

        # Current gait timing estimate for heelstrike vs clean mid-stance gating
        in_clean_single_stance = False
        if t >= t_stand:
            t_w_now = t - t_stand
            phi_now = (t_w_now % step_T) / step_T
            ds_cur = ds_frac + 0.06 * (float(np.clip((0.60 - mu_hat) / 0.42, 0.0, 1.0)) if adaptive_cone else 0.0)
            if phi_now >= ds_cur:
                s_sw_now = (phi_now - ds_cur) / (1.0 - ds_cur)
                in_clean_single_stance = (0.14 <= s_sw_now <= 0.94)

        # Low-pass filter sole slip ONLY during clean loaded single-stance (zero dry-heelstrike false triggers)
        alpha_f = 1.0 - float(np.exp(-dt / 0.012))
        if in_clean_single_stance and st_fz > 260.0:
            v_slip_lpf = (1.0 - alpha_f) * v_slip_lpf + alpha_f * st_v_slip
            if v_slip_lpf > 0.045:
                slip_consec += 1
                non_slip_clean_s = 0.0
            elif v_slip_lpf < 0.022:
                slip_consec = 0
                non_slip_clean_s += dt
        else:
            v_slip_lpf = (1.0 - alpha_f) * v_slip_lpf
            slip_consec = 0

        # Update causal blind slip observer ONLY in adaptive mode during clean stance
        # Require sustained >= 0.70 s clean non-slip single-stance before allowing upward recovery
        if adaptive_cone and in_clean_single_stance:
            if slip_consec >= 3:
                obs_v_slip = v_slip_lpf
            elif non_slip_clean_s >= 0.70 and v_slip_lpf < 0.014:
                obs_v_slip = 0.010
            else:
                obs_v_slip = 0.025  # Hold band: neither drops nor recovers prematurely mid-oil
            mu_hat = update_stance_slip_observer(
                mu_hat=mu_hat,
                v_slip_mps=obs_v_slip,
                f_tangential_n=st_ft,
                fz_n=st_fz,
                dt=dt,
            )
        mu_min_observed = min(mu_min_observed, mu_hat)

        # Causal speed & lateral stance adaptation from estimated mu_hat (smoothly slewed)
        slip_conf_raw = float(np.clip((0.60 - mu_hat) / 0.42, 0.0, 1.0)) if adaptive_cone else 0.0
        alpha_sc = 1.0 - float(np.exp(-dt / 0.14))
        slip_conf_s = (1.0 - alpha_sc) * slip_conf_s + alpha_sc * slip_conf_raw
        slip_conf = slip_conf_raw
        vx_tgt = vx_nom * (1.0 - 0.44 * slip_conf_s) if t >= t_stand else 0.0
        vx_ramp = float(np.clip((t - t_stand) / 0.55, 0.0, 1.0))
        vx_cmd = vx_tgt * vx_ramp
        by_eff = by_nom - 0.012 * slip_conf_s
        ds_eff = ds_frac + 0.04 * slip_conf_s

        dcm = com[:2] + com_vel[:2] / omega
        bx_cmd = vx_cmd * step_T / (np.exp(omega * step_T) - 1.0) if vx_cmd > 1e-4 else 0.0

        # Gait state machine
        s_stand = 0.5 * (1.0 - float(np.cos(np.pi * np.clip(t / t_stand, 0.0, 1.0))))
        if t < t_stand:
            swing = None
        else:
            t_w = t - t_stand
            step_idx = int(t_w / step_T)
            phi = (t_w % step_T) / step_T
            if step_idx != step_prev:
                step_prev = step_idx
                stance_side = 1 if (step_idx % 2 == 0) else -1
                sw_start_pos = (p_r if stance_side == 1 else p_l).copy()
                sw_start_pos[2] = max(0.0, sw_start_pos[2])
                prev_pdes = sw_start_pos.copy()
                swing_first_tick = True

            if phi < ds_eff:
                s = phi / max(ds_eff, 1e-4)
                smooth = 0.5 * (1.0 - np.cos(np.pi * s))
                if step_idx == 0:
                    alpha_l_ds = float(np.clip(0.50 + 0.42 * smooth, 0.1, 0.98))
                else:
                    alpha_l_ds = smooth if stance_side == 1 else (1.0 - smooth)
                alpha_l, alpha_r = alpha_l_ds, 1.0 - alpha_l_ds
                swing = None
            else:
                alpha_l = 1.0 if stance_side == 1 else 0.0
                alpha_r = 1.0 - alpha_l
                swing = "R" if stance_side == 1 else "L"
                s_sw = (phi - ds_eff) / (1.0 - ds_eff)

        z_ref = z_c - 0.020 * slip_conf
        fz_tot = total_mass * (g + 160.0 * (z_ref - com[2]) - 26.0 * com_vel[2])
        fz_tot = float(np.clip(fz_tot, 180.0, 1100.0))

        if t < t_stand:
            c_tgt = c0_xy + np.array([0.005 * s_stand, by_nom * 0.65 * s_stand])
            f_xy = total_mass * np.array([
                70.0 * (c_tgt[0] - com[0]) - 14.0 * com_vel[0],
                95.0 * (c_tgt[1] - com[1]) - 16.0 * com_vel[1],
            ])
            # ZMP-consistent weight transfer keeps lateral net torque ~ 0 during standup
            p_zmp_y = float(np.clip(com[1] - f_xy[1] / (total_mass * (omega**2)), p_r[1], p_l[1]))
            alpha_l = float(np.clip((p_zmp_y - p_r[1]) / max(p_l[1] - p_r[1], 0.05), 0.12, 0.88))
            alpha_r = 1.0 - alpha_l
        elif swing is None:
            p_cop_des = alpha_l * p_l[:2] + alpha_r * p_r[:2]
            f_xy = total_mass * np.array([
                4.2 * (vx_cmd - com_vel[0]),
                32.0 * (p_cop_des[1] - com[1]) - 6.0 * com_vel[1],
            ])
        else:
            p_st = p_l if stance_side == 1 else p_r
            cop_x = p_st[0] + np.clip(0.25 * (dcm[0] - (p_st[0] + bx_cmd)), -0.05, 0.08)
            cop_y = p_st[1] + np.clip(0.25 * (dcm[1] - (p_st[1] - stance_side * by_eff)), -0.03, 0.03)
            f_xy = total_mass * (omega**2) * np.array([com[0] - cop_x, com[1] - cop_y])
            f_xy = np.clip(f_xy, -220.0, 220.0)

        tau_trunk = np.array([
            -310.0 * roll - 34.0 * droll,
            -290.0 * pitch - 34.0 * dpitch,
            -95.0 * yaw - 12.0 * dyaw,
        ])

        fz_l = alpha_l * fz_tot
        fz_r = alpha_r * fz_tot

        fxy_l_des = alpha_l * f_xy
        fxy_r_des = alpha_r * f_xy
        if adaptive_cone:
            fxy_l_des = causal_friction_cone_clamp(fxy_l_des, fz_l, mu_hat, safety_factor=0.65)
            fxy_r_des = causal_friction_cone_clamp(fxy_r_des, fz_r, mu_hat, safety_factor=0.65)

        yaw_atten = 1.0 - 0.96 * slip_conf

        w_l = np.zeros(6)
        w_r = np.zeros(6)
        if alpha_l > 0.01:
            tau_z_l = alpha_l * tau_trunk[2] * yaw_atten
            if adaptive_cone and slip_conf > 0.2:
                tau_z_l = float(np.clip(tau_z_l, -0.0015 * fz_l, 0.0015 * fz_l))
            w_l = np.array([
                fxy_l_des[0],
                fxy_l_des[1],
                fz_l,
                np.clip(alpha_l * tau_trunk[0], -0.05 * fz_l, 0.05 * fz_l),
                np.clip(alpha_l * tau_trunk[1], -0.10 * fz_l, 0.10 * fz_l),
                tau_z_l,
            ])
        if alpha_r > 0.01:
            tau_z_r = alpha_r * tau_trunk[2] * yaw_atten
            if adaptive_cone and slip_conf > 0.2:
                tau_z_r = float(np.clip(tau_z_r, -0.0015 * fz_r, 0.0015 * fz_r))
            w_r = np.array([
                fxy_r_des[0],
                fxy_r_des[1],
                fz_r,
                np.clip(alpha_r * tau_trunk[0], -0.05 * fz_r, 0.05 * fz_r),
                np.clip(alpha_r * tau_trunk[1], -0.10 * fz_r, 0.10 * fz_r),
                tau_z_r,
            ])

        j_l = np.vstack([jac_lp, jac_lr])
        j_r = np.vstack([jac_rp, jac_rr])
        tau_gen = data.qfrc_bias.copy()
        if alpha_l > 0.01:
            tau_gen -= j_l.T @ w_l
        if alpha_r > 0.01:
            tau_gen -= j_r.T @ w_r

        tau_ctrl = np.array([tau_gen[idx] for idx in act_vidx])

        if swing is not None:
            p_st = p_l if stance_side == 1 else p_r
            s_sw_side = -1 if stance_side == 1 else 1
            tgt_x = np.clip(dcm[0] - bx_cmd, p_st[0] - 0.08, p_st[0] + 0.42)
            tgt_y = dcm[1] + s_sw_side * by_eff - 0.08 * com[1]
            if s_sw_side == -1:
                tgt_y = np.clip(tgt_y, p_st[1] - 0.34, p_st[1] - 0.15)
            else:
                tgt_y = np.clip(tgt_y, p_st[1] + 0.15, p_st[1] + 0.34)

            smooth_xy = 0.5 * (1.0 - np.cos(np.pi * s_sw))
            z_des = h_lift * np.sin(np.pi * s_sw) - 0.002 * (s_sw**2)
            p_des = np.array([
                sw_start_pos[0] + smooth_xy * (tgt_x - sw_start_pos[0]),
                sw_start_pos[1] + smooth_xy * (tgt_y - sw_start_pos[1]),
                z_des,
            ])
            v_des = np.zeros(3) if swing_first_tick else (p_des - prev_pdes) / dt
            swing_first_tick = False
            prev_pdes = p_des.copy()

            p_cur = p_r if swing == "R" else p_l
            v_cur = v_r if swing == "R" else v_l
            r_cur = r_r if swing == "R" else r_l
            w_cur = (jac_rr @ data.qvel) if swing == "R" else (jac_lr @ data.qvel)
            j_sw = j_r if swing == "R" else j_l
            sw_dofs = r_leg_v if swing == "R" else l_leg_v
            sw_acts = r_leg_act if swing == "R" else l_leg_act

            r_err = mat_to_rotvec_err(np.eye(3), r_cur)
            f_sw = np.concatenate([
                np.array([1500.0, 1500.0, 1900.0]) * (p_des - p_cur)
                + np.array([70.0, 70.0, 85.0]) * (v_des - v_cur),
                np.array([100.0, 130.0, 80.0]) * r_err
                - np.array([7.0, 9.0, 6.0]) * w_cur,
            ])
            tau_sw_full = data.qfrc_bias + j_sw.T @ f_sw
            for ai, vi in zip(sw_acts, sw_dofs):
                tau_ctrl[ai] = tau_sw_full[vi]

            st_acts = l_leg_act if stance_side == 1 else r_leg_act
            hip_shear_atten = 1.0 - 0.15 * slip_conf
            tau_ctrl[st_acts[0]] += (50.0 * yaw + 6.0 * dyaw) * yaw_atten
            tau_ctrl[st_acts[1]] += (110.0 * roll + 12.0 * droll) * hip_shear_atten
            tau_ctrl[st_acts[2]] += (100.0 * pitch + 11.0 * dpitch) * hip_shear_atten
        else:
            hip_shear_atten = 1.0 - 0.15 * slip_conf
            tau_ctrl[l_leg_act[1]] += (60.0 * roll + 7.0 * droll) * hip_shear_atten
            tau_ctrl[r_leg_act[1]] += (60.0 * roll + 7.0 * droll) * hip_shear_atten
            tau_ctrl[l_leg_act[2]] += (50.0 * pitch + 6.0 * dpitch) * hip_shear_atten
            tau_ctrl[r_leg_act[2]] += (50.0 * pitch + 6.0 * dpitch) * hip_shear_atten

        # Upper-body posture & counter-swing
        q = np.array([data.qpos[idx] for idx in act_qidx])
        qd = np.array([data.qvel[idx] for idx in act_vidx])
        q_t = q_init.copy()
        arm_amp = 0.25 * np.clip(com_vel[0] / 0.55, 0.0, 1.2)
        q_t[idx_map["act_left_shoulder_pitch"]] = arm_amp * (-stance_side)
        q_t[idx_map["act_right_shoulder_pitch"]] = arm_amp * stance_side
        for i in upper_act:
            name = act_names[i]
            kp = 300.0 if ("waist" in name or "torso" in name) else 130.0
            kd = 24.0 if ("waist" in name or "torso" in name) else 10.0
            tau_ctrl[i] = kp * (q_t[i] - q[i]) - kd * qd[i]

        tau_ctrl[idx_map["act_left_ankle_roll"]] += -0.45 * qd[idx_map["act_left_ankle_roll"]]
        tau_ctrl[idx_map["act_right_ankle_roll"]] += -0.45 * qd[idx_map["act_right_ankle_roll"]]

        clamp_and_apply_ctrl(model, data, tau_ctrl)

        mujoco.mj_step(model, data)

        pelvis_z = float(data.qpos[2])
        mu_true = terrain_friction_at(st_x)
        max_slip_speed = max(max_slip_speed, st_v_slip if t >= t_stand and st_fz > 140.0 else 0.0)
        if t >= t_stand and st_fz > 140.0 and st_v_slip > 0.032:
            oil_slip_events += 1
        if float(com[0]) > OIL_PATCH_END_X + 0.15 and pelvis_z > 0.72:
            cleared_oil_exit = True

        if step % 5 == 0:
            l_knee = abs(float(data.ctrl[idx_map["act_left_knee"]]))
            r_knee = abs(float(data.ctrl[idx_map["act_right_knee"]]))
            times.append(round(t, 4))
            com_x_log.append(float(com[0]))
            pelvis_z_log.append(pelvis_z)
            roll_log.append(float(np.degrees(roll)))
            pitch_log.append(float(np.degrees(pitch)))
            mu_hat_log.append(float(mu_hat))
            mu_true_log.append(mu_true)
            slip_spd_log.append(st_v_slip if t >= t_stand and st_fz > 140.0 else 0.0)
            grf_ratio_log.append(float(st_ft / st_fz) if st_fz > 80.0 else 0.0)
            fz_log.append(fz_total_meas)
            knee_tau_log.append(max(l_knee, r_knee))

        if pelvis_z < 0.60 or abs(roll) > 0.70 or abs(pitch) > 0.70:
            fell = True
            fall_time = round(t, 3)
            break

    return {
        "adaptive_cone": adaptive_cone,
        "times": times,
        "com_x": com_x_log,
        "pelvis_z": pelvis_z_log,
        "roll_deg": roll_log,
        "pitch_deg": pitch_log,
        "mu_hat": mu_hat_log,
        "mu_true": mu_true_log,
        "slip_speed_mps": slip_spd_log,
        "grf_ratio": grf_ratio_log,
        "fz_total_n": fz_log,
        "knee_tau_nm": knee_tau_log,
        "summary": {
            "survived": not fell,
            "fall_time_s": fall_time,
            "cleared_oil_patch": bool(cleared_oil_exit and not fell),
            "distance_walked_m": round(float(com_x_log[-1] - settled_x), 3) if com_x_log else 0.0,
            "final_com_x_m": round(float(com_x_log[-1]), 3) if com_x_log else 0.0,
            "duration_s": round(float(times[-1]), 3) if times else 0.0,
            "roll_rms_deg": round(float(np.sqrt(np.mean(np.square(roll_log)))), 2) if roll_log else 0.0,
            "pitch_rms_deg": round(float(np.sqrt(np.mean(np.square(pitch_log)))), 2) if pitch_log else 0.0,
            "min_mu_hat_detected": round(float(mu_min_observed), 3),
            "final_mu_hat": round(float(mu_hat), 3),
            "max_stance_slip_mps": round(float(max_slip_speed), 3),
            "slip_detection_ticks": int(oil_slip_events),
            "peak_knee_torque_nm": round(float(max(knee_tau_log)), 1) if knee_tau_log else 0.0,
            "skyhook_max_n": round(float(skyhook_max), 4),
        },
    }


def render_plot(base_dir: str, baseline: dict, adaptive: dict) -> str:
    """Save 4-panel oil-patch slip A/B telemetry plot."""
    plt.style.use("dark_background")
    fig, axes = plt.subplots(2, 2, figsize=(15, 9), facecolor="#0A0F1A")
    fig.suptitle(
        "FIGURE 05 // MUJOCO 3.6 BLIND OIL-PATCH SLIP RECOVERY "
        f"(mu = {MU_DRY:.2f} -> {MU_OIL:.2f} -> {MU_DRY:.2f}, SKYHOOK = 0.0 N)",
        fontsize=13,
        fontweight="bold",
        color="#38BDF8",
        y=0.98,
    )

    for ax in axes.flat:
        ax.set_facecolor("#0F172A")
        ax.grid(True, linestyle="--", alpha=0.28, color="#334155")

    # 1. Forward Progression X(t) with Oil Zone Shading
    ax = axes[0, 0]
    ax.axhspan(OIL_PATCH_START_X, OIL_PATCH_END_X, color="#F59E0B", alpha=0.16, label="Oil Slick (mu=0.18)")
    ax.plot(adaptive["times"], adaptive["com_x"], color="#10B981", lw=2.3, label="Adaptive Cone WBC (Survived)")
    ax.plot(baseline["times"], baseline["com_x"], color="#F43F5E", lw=1.9, ls="--", label="Baseline WBC (No Cone)")
    ax.set_title("Forward CoM Progression Across Oil Patch [0.55 - 1.55 m]", fontsize=10.5, color="#E2E8F0")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("CoM X Position (m)")
    ax.legend(loc="upper left", fontsize=8.2)

    # 2. Blind Causal Friction Estimate mu_hat vs True Ground mu
    ax = axes[0, 1]
    ax.plot(adaptive["times"], adaptive["mu_true"], color="#F59E0B", lw=1.8, ls=":", label="Ground Truth mu(X)")
    ax.plot(adaptive["times"], adaptive["mu_hat"], color="#38BDF8", lw=2.3, label="Blind Causal Observer mu_hat")
    ax.axhline(MU_OIL, color="#FB7185", lw=1.0, ls="--", alpha=0.6)
    ax.set_ylim(0.0, 1.35)
    ax.set_title("Zero-Oracle Stance Slip Observer vs Surface Friction", fontsize=10.5, color="#E2E8F0")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Friction Coefficient (mu)")
    ax.legend(loc="upper right", fontsize=8.2)

    # 3. Attitude Stability (Roll / Pitch)
    ax = axes[1, 0]
    ax.plot(adaptive["times"], adaptive["roll_deg"], color="#10B981", lw=2.0, label="Adaptive Roll (deg)")
    ax.plot(adaptive["times"], adaptive["pitch_deg"], color="#38BDF8", lw=2.0, label="Adaptive Pitch (deg)")
    ax.plot(baseline["times"], baseline["roll_deg"], color="#F43F5E", lw=1.5, ls="--", alpha=0.85, label="Baseline Roll (deg)")
    ax.set_title("Floating-Base Attitude Control Across Low-Friction Spill", fontsize=10.5, color="#E2E8F0")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Body Tilt (deg)")
    ax.legend(loc="best", fontsize=8.0)

    # 4. Stance Sole Slip Speed & Total Ground Normal Force
    ax = axes[1, 1]
    ax.plot(adaptive["times"], adaptive["slip_speed_mps"], color="#10B981", lw=2.0, label="Adaptive Stance Slip Speed (m/s)")
    ax.plot(baseline["times"], baseline["slip_speed_mps"], color="#F43F5E", lw=1.7, ls="--", label="Baseline Stance Slip Speed (m/s)")
    ax.axhline(0.032, color="#F59E0B", lw=1.1, ls=":", label="Slip Trigger (0.032 m/s)")
    ax.set_title("Measured Stance-Sole Contact Slip Velocity", fontsize=10.5, color="#E2E8F0")
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Sole Tangential Speed (m/s)")
    ax.legend(loc="upper left", fontsize=8.0)

    plt.tight_layout(rect=[0, 0, 1, 0.94])
    out_png = os.path.join(base_dir, "figure05_mujoco_slippery_benchmark.png")
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    return out_png


def main() -> None:
    print("=========================================================================")
    print("FIGURE 05 // MUJOCO 3.6 OIL-PATCH SLIP RECOVERY & FRICTION-CONE WBC")
    print("=========================================================================")

    baseline = run_trial(adaptive_cone=False, max_sim_s=10.0)
    adaptive = run_trial(adaptive_cone=True, max_sim_s=10.0)

    bs = baseline["summary"]
    ad = adaptive["summary"]
    print(
        f"[*] Baseline (No Slip Cone):  survived={bs['survived']} (fall={bs['fall_time_s']}s) | "
        f"dist={bs['distance_walked_m']}m | max_slip={bs['max_stance_slip_mps']}m/s"
    )
    print(
        f"[*] Adaptive (Blind Cone):    survived={ad['survived']} | cleared_oil={ad['cleared_oil_patch']} | "
        f"dist={ad['distance_walked_m']}m (X={ad['final_com_x_m']}m)"
    )
    print(
        f"[*] Blind Slip Observer:      min_mu_hat={ad['min_mu_hat_detected']} -> recovered={ad['final_mu_hat']} | "
        f"max_slip={ad['max_stance_slip_mps']}m/s | Roll/Pitch RMS={ad['roll_rms_deg']}/{ad['pitch_rms_deg']} deg"
    )
    print(
        f"[*] Torque & Contact Checks:  peak_knee={ad['peak_knee_torque_nm']} Nm | "
        f"skyhook_max={ad['skyhook_max_n']} N"
    )

    assert ad["skyhook_max_n"] == 0.0, "Zero skyhook violated!"
    assert not bs["survived"], "Expected unmitigated high-stride baseline to fail on mu=0.18 oil slick!"
    assert ad["survived"] and ad["cleared_oil_patch"], "Adaptive friction-cone WBC must survive and clear oil patch!"
    assert ad["min_mu_hat_detected"] <= 0.25, "Blind observer did not detect low-mu oil patch!"
    assert ad["final_mu_hat"] >= ad["min_mu_hat_detected"] + 0.15, "Dry-exit traction recovery did not trigger!"
    assert ad["roll_rms_deg"] < 6.0 and ad["pitch_rms_deg"] < 6.0

    base_dir = os.path.dirname(__file__)
    out_png = render_plot(base_dir, baseline, adaptive)
    print(f"[+] Saved Oil-Patch Slip Recovery plot: {out_png}")

    report = {
        "mujoco_version": mujoco.__version__,
        "skyhook_force_n": 0.0,
        "zero_oracle_controller": True,
        "oil_patch_x_range_m": [OIL_PATCH_START_X, OIL_PATCH_END_X],
        "mu_dry": MU_DRY,
        "mu_oil": MU_OIL,
        "ab_baseline_unmitigated": bs,
        "adaptive_blind_friction_cone": ad,
        "status": "PASS",
    }
    out_json = os.path.join(base_dir, "figure05_slippery_walk_telemetry.json")
    with open(out_json, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(f"[+] Saved Oil-Patch Slip Telemetry JSON: {out_json}")
    print("[PASS] Module #24 MuJoCo Oil-Patch Slip Recovery verified cleanly.")


if __name__ == "__main__":
    main()
