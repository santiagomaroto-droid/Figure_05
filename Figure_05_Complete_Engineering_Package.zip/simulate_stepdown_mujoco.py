"""
Figure 05 - Skyhook-Free MuJoCo 3.6 Discrete -75 mm Pallet Curb Step-Down Controller
==================================================================================
Authors: Santiago Maroto (Lead Researcher) & Project Figure 05 Engineering Group
Target: Kyle Edelberg & Brett Adcock, Figure AI

Architecture (100% Pure Rigid-Body Physics, Zero Skyhook Forces):
1. Strict skyhook prohibition: `data.qfrc_applied[:] = 0.0` at every 500 Hz step.
2. Elevated solid upper pallet platform (`+75.0 mm` at `X <= 0.40 m`) with a discrete
   vertical `-75.0 mm` drop-off onto the factory lower floor (`z = 0.0 m`).
3. Latched-plateau Englsberger DCM foothold planner preventing sole straddling over
   `[x_drop - 0.135, x_drop + 0.135]` combined with heel-clearing downward swing profile.
4. Smooth CoM-synchronized pelvis lowering and damped touchdown impedance absorbing the
   75 mm vertical drop cleanly before sustained lower-floor locomotion.
"""

import json
import os

import matplotlib.pyplot as plt
import mujoco
import numpy as np

from figure05_mujoco_common import (
    build_actuator_mappings,
    mat_to_rotvec_err,
    setup_crouched_biped,
    sum_support_grfs,
)


def upper_deck_height_at(x: float, x_drop: float = 0.40, step_h: float = 0.075) -> float:
    """Return exact rigid surface height Z [m] for an elevated deck over `x <= x_drop`."""
    return step_h if x <= x_drop else 0.0


def swing_descent_profile(
    s: float,
    z_start: float,
    z_land: float,
    step_h: float,
    swing_clear: float,
    step_T: float,
) -> tuple[float, float]:
    """
    Compute swing-foot vertical target Z [m] and Vz [m/s] over s in [0, 1].

    Holds upper clearance across `s in [0, 0.35]` when descending off the `+75 mm`
    curb (`z_start > z_land + 0.01`) so the heel clears `x_drop` before dropping smoothly.
    """
    stepping_down = (step_h > 0.0) and (z_start > z_land + 0.01)
    z_touch = z_land - (0.001 if stepping_down else 0.003)
    if stepping_down:
        u_z = float(np.clip((s - 0.22) / 0.78, 0.0, 1.0))
        z_base = z_start + (z_touch - z_start) * (3.0 * u_z ** 2 - 2.0 * u_z ** 3)
        if 0.22 < s < 1.0:
            dz_base_dt = (z_touch - z_start) * (6.0 * u_z * (1.0 - u_z)) / (0.78 * step_T)
        else:
            dz_base_dt = 0.0
        arc = (swing_clear * 0.85) * (np.sin(np.pi * s) ** 2)
        darc_dt = (swing_clear * 0.85) * (np.pi / step_T) * np.sin(2.0 * np.pi * s)
    else:
        z_base = z_start + (z_touch - z_start) * (3.0 * s ** 2 - 2.0 * s ** 3)
        dz_base_dt = (z_touch - z_start) * (6.0 * s * (1.0 - s)) / step_T
        arc = swing_clear * (np.sin(np.pi * s) ** 2)
        darc_dt = swing_clear * (np.pi / step_T) * np.sin(2.0 * np.pi * s)

    return float(z_base + arc), float(dz_base_dt + darc_dt)


def run_stepdown_simulation(
    verbose: bool = False,
    step_h: float = 0.075,
    x_drop: float = 0.40,
) -> None:
    print("=================================================================")
    print("FIGURE 05: SKYHOOK-FREE MUJOCO 3.6 -75 MM CURB STEP-DOWN")
    print("=================================================================")

    base_dir = os.path.dirname(os.path.abspath(__file__))
    xml_path = os.path.join(base_dir, "figure05_mujoco.xml")
    with open(xml_path, "r", encoding="utf-8") as f:
        xml_str = f.read()

    # Elevated pallet platform from X = -1.60 m to X = x_drop (+0.40 m), height +step_h
    x_min_deck = -1.60
    deck_half_len = 0.5 * (x_drop - x_min_deck)
    deck_pos_x = x_min_deck + deck_half_len
    deck_pos_z = 0.5 * step_h

    deck_geom_xml = (
        f'\n        <geom name="upper_pallet_deck" type="box" contype="1" conaffinity="1" '
        f'pos="{deck_pos_x:.4f} 0.0 {deck_pos_z:.5f}" '
        f'size="{deck_half_len:.4f} 1.20 {deck_pos_z:.5f}" '
        f'rgba="0.22 0.28 0.38 1.0" friction="1.0 0.005 0.0005"/>\n'
    )
    if "</worldbody>" not in xml_str:
        raise RuntimeError("Missing </worldbody> closing tag in figure05_mujoco.xml")
    xml_down = xml_str.replace("</worldbody>", deck_geom_xml + "    </worldbody>", 1)

    model = mujoco.MjModel.from_xml_string(xml_down)
    data = mujoco.MjData(model)

    dt = model.opt.timestep
    g = 9.80665
    total_mass = float(np.sum(model.body_mass))

    setup_crouched_biped(model, data)
    # Place both feet cleanly on top of the +75 mm elevated platform
    data.qpos[2] += step_h
    data.qvel[:] = 0.0
    mujoco.mj_forward(model, data)

    maps = build_actuator_mappings(model)
    act_qidx = maps["act_qidx"]
    act_vidx = maps["act_vidx"]
    idx_map = maps["idx_map"]
    l_leg_v = maps["l_leg_v"]
    r_leg_v = maps["r_leg_v"]
    l_leg_act = maps["l_leg_act"]
    r_leg_act = maps["r_leg_act"]
    upper_act = maps["upper_act"]
    q_init = np.array([data.qpos[idx] for idx in act_qidx])

    l_site = model.site("left_foot_contact").id
    r_site = model.site("right_foot_contact").id
    l_body = model.body("left_ankle").id
    r_body = model.body("right_ankle").id
    floor_geom = model.geom("floor").id
    deck_geom = model.geom("upper_pallet_deck").id
    support_geoms = {floor_geom, deck_geom}
    pelvis_id = model.body("pelvis").id

    jac_com = np.zeros((3, model.nv))
    jac_p_l = np.zeros((3, model.nv))
    jac_r_l = np.zeros((3, model.nv))
    jac_p_r = np.zeros((3, model.nv))
    jac_r_r = np.zeros((3, model.nv))

    # Gait & DCM parameters
    step_T = 0.42
    ds_frac = 0.16
    half_y = 0.105
    swing_clear = 0.080
    z_nom = 0.870
    omega = np.sqrt(g / z_nom)
    b_val = np.exp(omega * step_T)
    y_off_nom = (2.0 * half_y) / (b_val + 1.0)
    k_dcm = 1.45

    duration_s = 6.0
    n_steps = int(duration_s / dt)
    settle_steps = 140

    swing_side = "left"
    sw_start_pos = data.site_xpos[l_site].copy()
    v_x_target = 0.38
    sw_tgt_x = sw_start_pos[0] + 0.5 * v_x_target * step_T
    sw_tgt_y = half_y
    step_down_mode = False
    z_ground_smooth = step_h

    l_knee_id = idx_map["act_left_knee"]
    r_knee_id = idx_map["act_right_knee"]

    t_hist, x_hist, z_hist = [], [], []
    roll_hist, pitch_hist = [], []
    lf_x_hist, rf_x_hist = [], []
    lf_z_hist, rf_z_hist = [], []
    l_grf_hist, r_grf_hist = [], []
    knee_trq_hist = []
    fallen = False

    r_pelv_des = np.array([
        [np.cos(0.035), 0.0, np.sin(0.035)],
        [0.0, 1.0, 0.0],
        [-np.sin(0.035), 0.0, np.cos(0.035)],
    ])
    r_flat = np.eye(3)

    for step in range(n_steps):
        t = step * dt
        mujoco.mj_forward(model, data)

        # CRITICAL: ZERO SKYHOOK FORCES
        data.qfrc_applied[:] = 0.0

        p_l = data.site_xpos[l_site].copy()
        p_r = data.site_xpos[r_site].copy()
        r_l = data.site_xmat[l_site].reshape(3, 3)
        r_r = data.site_xmat[r_site].reshape(3, 3)

        mujoco.mj_jacSubtreeCom(model, data, jac_com, pelvis_id)
        p_com = data.subtree_com[pelvis_id].copy()
        v_com = jac_com @ data.qvel

        mujoco.mj_jacSite(model, data, jac_p_l, jac_r_l, l_site)
        mujoco.mj_jacSite(model, data, jac_p_r, jac_r_r, r_site)
        v_l = jac_p_l @ data.qvel
        w_l = jac_r_l @ data.qvel
        v_r = jac_p_r @ data.qvel
        w_r = jac_r_r @ data.qvel

        pelv_mat = data.body("pelvis").xmat.reshape(3, 3)
        pelv_w = data.qvel[3:6].copy()
        roll_pelv = float(np.arctan2(pelv_mat[2, 1], pelv_mat[2, 2]))
        pitch_pelv = float(-np.arcsin(np.clip(pelv_mat[2, 0], -1.0, 1.0)))

        l_grf, r_grf = sum_support_grfs(model, data, support_geoms, l_body, r_body)

        t_hist.append(t)
        x_hist.append(float(data.qpos[0]))
        z_hist.append(float(data.qpos[2]))
        roll_hist.append(float(np.rad2deg(roll_pelv)))
        pitch_hist.append(float(np.rad2deg(pitch_pelv)))
        lf_x_hist.append(float(p_l[0]))
        rf_x_hist.append(float(p_r[0]))
        lf_z_hist.append(float(p_l[2]))
        rf_z_hist.append(float(p_r[2]))
        l_grf_hist.append(l_grf)
        r_grf_hist.append(r_grf)

        local_floor = min(p_l[2], p_r[2])
        if data.qpos[2] - local_floor < 0.45:
            fallen = True
            print(f"[ABORT] Fall detected at t={t:.2f}s Z_pel={data.qpos[2]:.3f}m")
            break

        tau_step = 0.0
        step_num = 0
        if step < settle_steps:
            in_ds = True
            phase_sw = 0.0
            s_sign = 1.0
            step_down_mode = False
            if step == settle_steps - 1:
                sw_start_pos = p_l.copy()
                sw_tgt_x = min(p_r[0] + 0.14, x_drop - 0.145)
                sw_tgt_y = p_r[1] + 2.0 * half_y
        else:
            step_idx = step - settle_steps
            ticks_per_step = int(step_T / dt)
            step_num = step_idx // ticks_per_step
            tau_step = (step_idx % ticks_per_step) * dt
            if step_idx % ticks_per_step == 0 and step_idx > 0:
                swing_side = "right" if swing_side == "left" else "left"
                sw_start_pos = p_l.copy() if swing_side == "left" else p_r.copy()

            s_sign = 1.0 if swing_side == "left" else -1.0
            in_ds = tau_step < (ds_frac * step_T)
            p_st = p_r if swing_side == "left" else p_l

            v_des = v_x_target if step_num >= 1 else 0.25
            step_dx = v_des * step_T
            x_off = step_dx / (b_val - 1.0)
            dcm_x = p_com[0] + v_com[0] / omega
            dcm_y = p_com[1] + v_com[1] / omega

            if in_ds:
                phase_sw = 0.0
                sw_start_pos = p_l.copy() if swing_side == "left" else p_r.copy()
                x_end_pred = p_st[0] + (dcm_x - p_st[0]) * np.exp(omega * (1.0 - ds_frac) * step_T) - x_off
                step_down_mode = bool(
                    (x_end_pred >= x_drop - 0.125)
                    or (p_st[0] >= x_drop - 0.16)
                    or (sw_start_pos[2] < step_h - 0.02)
                )
            else:
                phase_sw = min(1.0, (tau_step - ds_frac * step_T) / ((1.0 - ds_frac) * step_T))

            if phase_sw < 0.85:
                tgt_x_raw = dcm_x - x_off
                if step_down_mode:
                    x_min = max(x_drop + 0.135, p_st[0] - 0.06)
                    x_max = max(x_min + 0.04, p_st[0] + 0.34)
                    sw_tgt_x = float(np.clip(tgt_x_raw, x_min, x_max))
                else:
                    x_min = p_st[0] - 0.06
                    x_max = max(x_min + 0.02, x_drop - 0.140)
                    sw_tgt_x = float(np.clip(tgt_x_raw, x_min, x_max))

                tgt_y_raw = dcm_y + s_sign * y_off_nom - 0.15 * p_com[1]
                y_a = p_st[1] + s_sign * 0.14
                y_b = p_st[1] + s_sign * 0.29
                sw_tgt_y = float(np.clip(tgt_y_raw, min(y_a, y_b), max(y_a, y_b)))

        p_l_xy, p_r_xy = p_l[:2], p_r[:2]
        if in_ds:
            w_l_share, w_r_share = 0.5, 0.5
            p_zmp_st = 0.5 * (p_l + p_r)
        elif swing_side == "left":
            w_l_share, w_r_share = 0.0, 1.0
            p_zmp_st = p_r.copy()
        else:
            w_l_share, w_r_share = 1.0, 0.0
            p_zmp_st = p_l.copy()

        dcm_x = p_com[0] + v_com[0] / omega
        dcm_y = p_com[1] + v_com[1] / omega

        if step < settle_steps:
            zmp_ref_x = p_zmp_st[0] - 0.015
            zmp_ref_y = 0.045 if dcm_y > -0.055 else -0.02
        elif in_ds:
            zmp_ref_x = p_zmp_st[0] - 0.01
            zmp_ref_y = p_zmp_st[1]
        else:
            step_dx = (v_x_target if step_num >= 1 else 0.25) * step_T
            x_off = step_dx / (b_val - 1.0)
            exp_tau = float(np.exp(omega * tau_step))
            dcm_nom_x = p_zmp_st[0] + x_off * exp_tau
            dcm_nom_y = p_zmp_st[1] + s_sign * y_off_nom * exp_tau
            zmp_ref_x = p_zmp_st[0] + k_dcm * (dcm_x - dcm_nom_x)
            zmp_ref_y = p_zmp_st[1] + k_dcm * (dcm_y - dcm_nom_y)

        # Smooth pelvis lowering synchronously as COM approaches & crosses drop edge
        descend_prog = float(np.clip((p_com[0] - (x_drop - 0.14)) / 0.34, 0.0, 1.0))
        z_target_deck = step_h * (1.0 - descend_prog)
        z_ground_smooth += 0.025 * (z_target_deck - z_ground_smooth)
        z_pelvis_ref = z_ground_smooth + z_nom

        fz_des = total_mass * (g + 420.0 * (z_pelvis_ref - p_com[2]) - 42.0 * v_com[2])
        fz_des = float(np.clip(fz_des, 0.35 * total_mass * g, 2.15 * total_mass * g))

        if in_ds:
            zmp_ref_x = float(np.clip(zmp_ref_x, min(p_l_xy[0], p_r_xy[0]) - 0.09, max(p_l_xy[0], p_r_xy[0]) + 0.09))
            zmp_ref_y = float(np.clip(zmp_ref_y, min(p_l_xy[1], p_r_xy[1]) - 0.04, max(p_l_xy[1], p_r_xy[1]) + 0.04))
        else:
            zmp_ref_x = float(np.clip(zmp_ref_x, p_zmp_st[0] - 0.10, p_zmp_st[0] + 0.10))
            zmp_ref_y = float(np.clip(zmp_ref_y, p_zmp_st[1] - 0.035, p_zmp_st[1] + 0.035))

        fx_des = total_mass * (g / z_nom) * (p_com[0] - zmp_ref_x)
        fy_des = total_mass * (g / z_nom) * (p_com[1] - zmp_ref_y)

        w_total = np.array([
            float(np.clip(fx_des, -260.0, 260.0)),
            float(np.clip(fy_des, -220.0, 220.0)),
            fz_des,
            0.0,
            0.0,
            0.0,
        ])

        e_rot = mat_to_rotvec_err(r_pelv_des, pelv_mat)
        tau_pelv = 650.0 * e_rot - 45.0 * pelv_w

        ctrl = np.zeros(model.nu)
        for i in upper_act:
            q_err = q_init[i] - data.qpos[act_qidx[i]]
            dq = data.qvel[act_vidx[i]]
            ctrl[i] = 160.0 * q_err - 14.0 * dq + data.qfrc_bias[act_vidx[i]]

        for side in ("left", "right"):
            is_left = side == "left"
            v_idx = l_leg_v if is_left else r_leg_v
            a_idx = l_leg_act if is_left else r_leg_act
            j_p = (jac_p_l if is_left else jac_p_r)[:, v_idx]
            j_r = (jac_r_l if is_left else jac_r_r)[:, v_idx]
            j_6 = np.vstack([j_p, j_r])
            p_cur = p_l if is_left else p_r
            v_cur = v_l if is_left else v_r
            r_cur = r_l if is_left else r_r
            w_cur = w_l if is_left else w_r
            w_share = w_l_share if is_left else w_r_share

            if w_share > 0.0:
                w_st = w_total * w_share
                w_st[3:6] = w_share * tau_pelv
                e_f = mat_to_rotvec_err(r_flat, r_cur)
                w_st[3:6] -= (180.0 * e_f - 18.0 * w_cur)
                w_st[4] += -w_st[2] * float(np.clip(zmp_ref_x - p_cur[0], -0.09, 0.09))
                w_st[3] += w_st[2] * float(np.clip(zmp_ref_y - p_cur[1], -0.035, 0.035))
                ctrl[a_idx] = data.qfrc_bias[v_idx] - j_6.T @ w_st
            else:
                s = phase_sw
                sw_dur = (1.0 - ds_frac) * step_T
                h_s = 3.0 * s ** 2 - 2.0 * s ** 3
                dh_dt = (6.0 * s * (1.0 - s)) / sw_dur
                sw_x = sw_start_pos[0] + (sw_tgt_x - sw_start_pos[0]) * h_s
                sw_y = sw_start_pos[1] + (sw_tgt_y - sw_start_pos[1]) * h_s
                sw_vx = (sw_tgt_x - sw_start_pos[0]) * dh_dt
                sw_vy = (sw_tgt_y - sw_start_pos[1]) * dh_dt

                z_land = upper_deck_height_at(sw_tgt_x, x_drop, step_h)
                sw_z, sw_vz = swing_descent_profile(
                    s=s,
                    z_start=float(sw_start_pos[2]),
                    z_land=z_land,
                    step_h=step_h,
                    swing_clear=swing_clear,
                    step_T=sw_dur,
                )

                pos_err = np.array([sw_x, sw_y, sw_z]) - p_cur
                vel_err = np.array([sw_vx, sw_vy, sw_vz]) - v_cur
                f_sw = np.array([2000.0, 2000.0, 2600.0]) * pos_err + np.array([85.0, 85.0, 110.0]) * vel_err

                e_rot_sw = mat_to_rotvec_err(r_flat, r_cur)
                m_sw = 240.0 * e_rot_sw - 18.0 * w_cur
                ctrl[a_idx] = data.qfrc_bias[v_idx] + j_6.T @ np.concatenate([f_sw, m_sw])

        ctrl = np.clip(ctrl, model.actuator_ctrlrange[:, 0], model.actuator_ctrlrange[:, 1])
        data.ctrl[:] = ctrl
        knee_trq_hist.append(float(max(abs(ctrl[l_knee_id]), abs(ctrl[r_knee_id]))))

        if verbose and step % 200 == 0:
            print(
                f"t={t:4.2f} X={data.qpos[0]:+.3f} Z={data.qpos[2]:.3f} "
                f"R={np.rad2deg(roll_pelv):+5.1f} P={np.rad2deg(pitch_pelv):+5.1f} "
                f"L=({p_l[0]:+.2f},{p_l[2]:.3f}) R=({p_r[0]:+.2f},{p_r[2]:.3f})"
            )
        mujoco.mj_step(model, data)

    t_arr = np.array(t_hist)
    x_final = float(x_hist[-1])
    z_initial = float(z_hist[0])
    z_final = float(z_hist[-1])
    lf_z_final = float(lf_z_hist[-1])
    rf_z_final = float(rf_z_hist[-1])
    roll_rms = float(np.sqrt(np.mean(np.array(roll_hist) ** 2)))
    pitch_rms = float(np.sqrt(np.mean(np.array(pitch_hist) ** 2)))
    peak_knee_nm = float(np.max(knee_trq_hist))
    peak_l_grf = float(np.max(l_grf_hist))
    peak_r_grf = float(np.max(r_grf_hist))
    both_descended = bool((not fallen) and (x_final > x_drop + 0.80) and (lf_z_hist[-1] < 0.05) and (rf_z_hist[-1] < 0.05) and (z_final < z_initial - 0.01))

    print(f"Total Simulated Time        : {t_arr[-1]:.2f} s ({len(t_arr)} physics steps)")
    print(f"Skyhook External Force      : 0.0 N (Strictly Disabled)")
    print(f"Drop Geometry               : -75.0 mm vertical pallet drop at X = {x_drop:.2f} m")
    print(f"Forward Distance Walked     : {x_final:.3f} m")
    print(f"Pelvis Elevation Change     : {z_final - z_initial:+.3f} m ({z_initial:.3f} -> {z_final:.3f} m)")
    print(f"Final Sole Height (L / R)   : {lf_z_final*1000:.1f} mm / {rf_z_final*1000:.1f} mm (Lower Floor = 0.0 mm)")
    print(f"Pelvis Attitude RMS (R / P) : {roll_rms:.2f} deg / {pitch_rms:.2f} deg")
    print(f"Peak Foot GRF (L / R)       : {peak_l_grf:.1f} N / {peak_r_grf:.1f} N")
    print(f"Peak Knee Torque            : {peak_knee_nm:.1f} Nm (Class-Gamma Limit 220 Nm)")
    print(f"Lower Floor Descent Status  : {'PASSED' if both_descended else 'FAILED'}")

    telemetry = {
        "module": "simulate_stepdown_mujoco.py",
        "mujoco_version": mujoco.__version__,
        "skyhook_force_n": 0.0,
        "duration_s": round(float(t_arr[-1]), 3),
        "drop_x_m": x_drop,
        "drop_height_mm": round(step_h * 1000.0, 1),
        "forward_distance_m": round(x_final, 3),
        "pelvis_z_start_m": round(z_initial, 3),
        "pelvis_z_end_m": round(z_final, 3),
        "pelvis_descent_cm": round((z_initial - z_final) * 100.0, 2),
        "left_foot_final_z_mm": round(lf_z_final * 1000.0, 1),
        "right_foot_final_z_mm": round(rf_z_final * 1000.0, 1),
        "roll_rms_deg": round(roll_rms, 2),
        "pitch_rms_deg": round(pitch_rms, 2),
        "peak_left_grf_n": round(peak_l_grf, 1),
        "peak_right_grf_n": round(peak_r_grf, 1),
        "peak_knee_torque_nm": round(peak_knee_nm, 1),
        "completed_without_fall": bool(not fallen),
        "both_feet_descended_to_floor": both_descended,
    }
    json_path = os.path.join(base_dir, "figure05_stepdown_telemetry.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(telemetry, f, indent=2)
    print(f"[SAVED] Telemetry JSON -> {json_path}")

    # 4-Panel Engineering Chart
    plt.style.use("dark_background")
    fig, axes = plt.subplots(2, 2, figsize=(15, 10))
    fig.patch.set_facecolor("#090d16")

    ax = axes[0, 0]
    ax.set_facecolor("#0f172a")
    gx = np.linspace(-0.20, max(2.2, x_final + 0.15), 500)
    gz_mm = np.where(gx <= x_drop, step_h * 1000.0, 0.0)
    ax.fill_between(gx, -15.0, gz_mm, color="#1e293b", alpha=0.95, label="Upper +75 mm Deck -> Lower Floor")
    ax.plot(gx, gz_mm, color="#94a3b8", lw=2.2)
    ax.plot(lf_x_hist, np.array(lf_z_hist) * 1000.0, color="#38bdf8", lw=2.0, label="Left Foot Sole Z(X)")
    ax.plot(rf_x_hist, np.array(rf_z_hist) * 1000.0, color="#f97316", lw=2.0, ls="--", label="Right Foot Sole Z(X)")
    ax.axvline(x_drop, color="#facc15", ls=":", lw=1.4, label=f"Drop Edge X = {x_drop:.2f} m")
    ax.set_title("1. Discrete -75 mm Pallet Curb Step-Down Z(X)", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Sagittal Position X [m]")
    ax.set_ylabel("Sole Elevation Z [mm]")
    ax.set_ylim(-15, 225)
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    ax = axes[0, 1]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, np.array(z_hist) * 100.0, color="#a855f7", lw=2.2, label="Pelvis COM Z [cm]")
    ax.plot(t_arr, np.array(lf_z_hist) * 100.0, color="#38bdf8", lw=1.6, label="Left Foot Z [cm]")
    ax.plot(t_arr, np.array(rf_z_hist) * 100.0, color="#f97316", lw=1.6, label="Right Foot Z [cm]")
    ax.axhline(step_h * 100.0, color="#94a3b8", ls=":", lw=1.2, label="Upper Deck (+7.5 cm)")
    ax.axhline(0.0, color="#10b981", ls="--", lw=1.2, label="Lower Floor (0.0 cm)")
    ax.set_title("2. Vertical Descent Profile (Z vs Time)", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Height [cm]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="center right")

    ax = axes[1, 0]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, roll_hist, color="#22d3ee", lw=1.8, label=f"Roll (RMS {roll_rms:.2f} deg)")
    ax.plot(t_arr, pitch_hist, color="#f43f5e", lw=1.8, label=f"Pitch (RMS {pitch_rms:.2f} deg)")
    ax.axhline(0.0, color="#64748b", lw=1.0, ls=":")
    ax.set_title("3. Skyhook-Free Step-Down Pelvis Attitude", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Orientation [deg]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    ax = axes[1, 1]
    ax.set_facecolor("#0f172a")
    ax.plot(t_arr, l_grf_hist, color="#38bdf8", lw=1.5, alpha=0.9, label=f"Left GRF (Peak {peak_l_grf:.0f} N)")
    ax.plot(t_arr, r_grf_hist, color="#f97316", lw=1.5, alpha=0.9, label=f"Right GRF (Peak {peak_r_grf:.0f} N)")
    ax.axhline(total_mass * g, color="#10b981", ls="--", lw=1.2, label=f"Robot Weight ({total_mass*g:.0f} N)")
    ax.set_title("4. True MuJoCo Deck & Lower Floor Impact GRF", fontweight="bold", color="#f8fafc")
    ax.set_xlabel("Time [s]")
    ax.set_ylabel("Vertical GRF [N]")
    ax.grid(alpha=0.2)
    ax.legend(fontsize=8, loc="upper right")

    fig.suptitle(
        f"FIGURE 05 | Skyhook-Free MuJoCo 3.6 Discrete -75 mm Curb Step-Down "
        f"(Walked {x_final:.2f} m, Both Feet Descended = {both_descended})",
        fontsize=14,
        fontweight="bold",
        color="#ffffff",
    )
    plt.tight_layout(rect=[0, 0, 1, 0.95])
    out_png = os.path.join(base_dir, "figure05_mujoco_stepdown_benchmark.png")
    plt.savefig(out_png, dpi=180, facecolor=fig.get_facecolor())
    plt.close()
    print(f"[SAVED] Benchmark Plot -> {out_png}")

    if step_h > 0.0 and not both_descended:
        raise AssertionError(f"Step-down check failed (X={x_final:.2f}m, fallen={fallen})")


if __name__ == "__main__":
    run_stepdown_simulation()
